--
-- backup_20151011-163642.sql.gz


DROP TABLE IF EXISTS `rel_atelier_computer`;
CREATE TABLE `rel_atelier_computer` (
  `id_atelier_computer` int(11) NOT NULL AUTO_INCREMENT,
  `id_atelier_rel` int(11) NOT NULL,
  `id_computer_rel` int(11) NOT NULL,
  PRIMARY KEY (`id_atelier_computer`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `rel_atelier_computer` VALUES ('1','9','1');
INSERT INTO `rel_atelier_computer` VALUES ('2','9','2');
INSERT INTO `rel_atelier_computer` VALUES ('3','9','3');
INSERT INTO `rel_atelier_computer` VALUES ('4','9','4');
INSERT INTO `rel_atelier_computer` VALUES ('5','9','5');


DROP TABLE IF EXISTS `rel_atelier_user`;
CREATE TABLE `rel_atelier_user` (
  `id_rel_atelier_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_atelier` int(11) NOT NULL DEFAULT '0',
  `id_user` int(11) NOT NULL DEFAULT '0',
  `status_rel_atelier_user` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_rel_atelier_user`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `rel_atelier_user` VALUES ('1','1','6','0');
INSERT INTO `rel_atelier_user` VALUES ('2','1','8','0');
INSERT INTO `rel_atelier_user` VALUES ('3','1','13','0');
INSERT INTO `rel_atelier_user` VALUES ('4','1','19','0');


DROP TABLE IF EXISTS `rel_forfait_espace`;
CREATE TABLE `rel_forfait_espace` (
  `id_forfait_espace` int(11) NOT NULL AUTO_INCREMENT,
  `id_forfait` int(11) NOT NULL,
  `id_espace` int(11) NOT NULL,
  PRIMARY KEY (`id_forfait_espace`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `rel_forfait_espace` VALUES ('111','3','1');
INSERT INTO `rel_forfait_espace` VALUES ('112','3','2');
INSERT INTO `rel_forfait_espace` VALUES ('113','1','1');
INSERT INTO `rel_forfait_espace` VALUES ('114','1','2');
INSERT INTO `rel_forfait_espace` VALUES ('115','2','1');
INSERT INTO `rel_forfait_espace` VALUES ('116','2','2');


DROP TABLE IF EXISTS `rel_forfait_user`;
CREATE TABLE `rel_forfait_user` (
  `id_rel_forfait_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_forfait` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_rel_forfait_user`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `rel_forfait_user` VALUES ('2','1','15');
INSERT INTO `rel_forfait_user` VALUES ('3','1','4');
INSERT INTO `rel_forfait_user` VALUES ('4','2','5');
INSERT INTO `rel_forfait_user` VALUES ('5','1','6');
INSERT INTO `rel_forfait_user` VALUES ('7','1','8');
INSERT INTO `rel_forfait_user` VALUES ('8','1','9');
INSERT INTO `rel_forfait_user` VALUES ('9','1','10');
INSERT INTO `rel_forfait_user` VALUES ('10','2','11');
INSERT INTO `rel_forfait_user` VALUES ('11','1','12');
INSERT INTO `rel_forfait_user` VALUES ('12','1','13');
INSERT INTO `rel_forfait_user` VALUES ('13','1','14');
INSERT INTO `rel_forfait_user` VALUES ('14','1','16');
INSERT INTO `rel_forfait_user` VALUES ('15','1','17');
INSERT INTO `rel_forfait_user` VALUES ('16','1','18');
INSERT INTO `rel_forfait_user` VALUES ('17','1','19');
INSERT INTO `rel_forfait_user` VALUES ('18','1','20');
INSERT INTO `rel_forfait_user` VALUES ('20','2','7');
INSERT INTO `rel_forfait_user` VALUES ('21','1','19');
INSERT INTO `rel_forfait_user` VALUES ('22','1','6');
INSERT INTO `rel_forfait_user` VALUES ('23','3','11');
INSERT INTO `rel_forfait_user` VALUES ('24','2','18');


DROP TABLE IF EXISTS `rel_inscription_forfait_user`;
CREATE TABLE `rel_inscription_forfait_user` (
  `id_rel_forfait_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_forfait` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_rel_forfait_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_inter_computer`;
CREATE TABLE `rel_inter_computer` (
  `id_inter_computer` int(11) NOT NULL AUTO_INCREMENT,
  `id_inter` int(11) NOT NULL DEFAULT '0',
  `id_computer` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_inter_computer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_level_usage_user`;
CREATE TABLE `rel_level_usage_user` (
  `id_level_usage_user` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_level_usage_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_session_cloture`;
CREATE TABLE `rel_session_cloture` (
  `id_cloture` int(11) NOT NULL AUTO_INCREMENT,
  `id_atelier` int(11) NOT NULL,
  `id_session` int(11) NOT NULL,
  PRIMARY KEY (`id_cloture`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_session_user`;
CREATE TABLE `rel_session_user` (
  `id_rel_session` int(11) NOT NULL AUTO_INCREMENT,
  `id_session` int(11) NOT NULL DEFAULT '0',
  `id_datesession` int(11) NOT NULL,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `status_rel_session` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_rel_session`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_url_rub`;
CREATE TABLE `rel_url_rub` (
  `id_url_rub` int(11) NOT NULL AUTO_INCREMENT,
  `id_url` int(11) NOT NULL,
  `id_rub` int(11) NOT NULL,
  PRIMARY KEY (`id_url_rub`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_usage_computer`;
CREATE TABLE `rel_usage_computer` (
  `id_usage_computer` int(11) NOT NULL AUTO_INCREMENT,
  `id_computer` int(11) NOT NULL DEFAULT '0',
  `id_usage` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_usage_computer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `rel_user_anim`;
CREATE TABLE `rel_user_anim` (
  `id_useranim` int(11) NOT NULL AUTO_INCREMENT,
  `id_animateur` int(11) NOT NULL,
  `id_epn` int(11) NOT NULL,
  `id_salle` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `anim_avatar` varchar(500) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_useranim`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `rel_user_anim` VALUES ('1','2','2','1','People-Avatar-Set-Circular-06.png');
INSERT INTO `rel_user_anim` VALUES ('2','3','1','1;2','People-Avatar-Set-Circular-13.png');
INSERT INTO `rel_user_anim` VALUES ('8','8664','1','1','People-Avatar-Set-Circular-18.png');
INSERT INTO `rel_user_anim` VALUES ('7','1','1','1;2','People-Avatar-Set-Circular-06.png');
INSERT INTO `rel_user_anim` VALUES ('9','21','1','2','People-Avatar-Set-Circular-08.png');
INSERT INTO `rel_user_anim` VALUES ('10','22','2','3','avatar04.png');


DROP TABLE IF EXISTS `rel_user_forfait`;
CREATE TABLE `rel_user_forfait` (
  `id_forfait` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_transac` int(11) NOT NULL,
  `total_atelier` int(11) NOT NULL,
  `depense` int(11) NOT NULL,
  `statut_forfait` int(11) NOT NULL,
  PRIMARY KEY (`id_forfait`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `rel_user_forfait` VALUES ('1','13','2','5','0','1');
INSERT INTO `rel_user_forfait` VALUES ('2','19','3','10','0','1');
INSERT INTO `rel_user_forfait` VALUES ('4','6','11','7','0','1');


DROP TABLE IF EXISTS `rel_utilisation_user`;
CREATE TABLE `rel_utilisation_user` (
  `id_utilisation_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisation` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `date_utilisation` date NOT NULL,
  PRIMARY KEY (`id_utilisation_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_as_stat`;
CREATE TABLE `tab_as_stat` (
  `id_stat` int(11) NOT NULL AUTO_INCREMENT,
  `type_AS` varchar(11) COLLATE latin1_general_ci DEFAULT NULL,
  `id_AS` int(11) NOT NULL,
  `date_AS` datetime DEFAULT NULL,
  `inscrits` int(11) NOT NULL,
  `presents` int(11) NOT NULL,
  `absents` int(11) NOT NULL,
  `attente` int(11) NOT NULL,
  `nbplace` int(11) NOT NULL,
  `statut_programmation` int(11) NOT NULL,
  `id_anim` int(11) NOT NULL,
  `id_epn` int(11) NOT NULL,
  PRIMARY KEY (`id_stat`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_as_stat` VALUES ('1','a','1','2015-01-10 11:00:00','12','12','0','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('2','a','2','2015-01-10 10:00:00','12','12','0','5','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('3','a','3','2015-01-17 10:00:00','12','12','0','4','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('4','a','8','2015-01-24 10:00:00','8','7','1','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('5','a','4','2015-01-24 11:00:00','12','7','5','2','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('6','a','9','2015-01-31 10:00:00','11','9','3','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('7','a','5','2015-02-03 18:00:00','11','5','6','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('8','a','7','2015-02-17 18:00:00','5','4','1','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('9','a','10','2015-02-18 10:00:00','12','9','3','3','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('10','a','11','2015-03-10 18:00:00','11','8','3','3','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('11','a','6','2015-02-10 18:00:00','10','0','0','0','12','3','8554','1');
INSERT INTO `tab_as_stat` VALUES ('12','a','19','2015-02-07 10:00:00','12','0','0','1','12','3','8554','1');
INSERT INTO `tab_as_stat` VALUES ('13','s','1','2015-01-07 10:00:00','5','5','0','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('14','s','1','2015-01-14 10:00:00','5','5','0','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('15','s','1','2015-01-21 10:00:00','5','5','0','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('16','s','1','2015-01-28 10:00:00','5','4','1','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('17','s','1','2015-02-04 10:00:00','5','5','0','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('18','s','1','2015-02-11 10:00:00','5','0','0','0','6','2','8554','1');
INSERT INTO `tab_as_stat` VALUES ('19','s','3','2015-03-11 10:00:00','7','7','0','0','8','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('20','a','14','2015-03-14 10:00:00','11','9','2','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('21','a','12','2015-03-17 18:00:00','11','8','3','1','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('22','s','3','2015-03-18 10:00:00','7','6','1','0','8','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('23','a','15','2015-03-21 10:00:00','12','11','1','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('24','a','16','2015-03-21 11:00:00','12','11','1','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('25','a','13','2015-03-24 18:00:00','12','11','1','5','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('26','s','3','2015-03-25 10:00:00','7','6','1','0','8','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('27','a','18','2015-03-28 10:00:00','11','9','2','3','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('28','s','3','2015-04-01 10:00:00','7','6','1','0','8','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('29','s','4','2015-04-04 10:00:00','6','4','2','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('30','s','4','2015-04-11 10:00:00','6','3','3','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('31','a','20','2015-04-11 11:00:00','11','9','2','2','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('32','a','21','2015-04-14 18:00:00','12','6','6','2','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('33','s','4','2015-04-18 10:00:00','6','4','2','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('34','a','22','2015-04-21 18:00:00','11','9','2','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('35','s','4','2015-04-22 10:00:00','6','3','3','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('36','a','23','2015-04-22 11:00:00','9','9','0','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('37','s','5','2015-05-16 10:00:00','4','2','2','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('38','a','24','2015-05-16 11:00:00','8','5','3','0','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('39','s','6','2015-05-19 18:00:00','11','5','6','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('40','s','5','2015-05-20 10:00:00','4','2','2','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('41','s','5','2015-05-23 10:00:00','4','3','1','0','6','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('42','s','6','2015-05-26 18:00:00','11','6','5','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('43','a','25','2015-05-27 10:00:00','12','9','3','1','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('44','s','6','2015-06-02 18:00:00','11','3','8','0','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('45','s','7','2015-06-03 10:00:00','11','4','7','1','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('46','a','27','2015-06-06 10:00:00','9','6','3','0','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('47','a','28','2015-06-06 11:00:00','7','5','2','0','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('48','a','29','2015-06-09 18:00:00','10','8','2','0','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('49','s','7','2015-06-10 10:00:00','8','6','2','1','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('50','a','30','2015-06-16 18:00:00','11','11','0','3','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('51','s','7','2015-06-17 10:00:00','11','7','4','1','12','1','8554','1');
INSERT INTO `tab_as_stat` VALUES ('52','a','31','2015-06-23 18:00:00','9','4','5','0','12','1','0','1');
INSERT INTO `tab_as_stat` VALUES ('53','s','7','2015-06-24 10:00:00','11','7','4','1','12','1','8554','1');


DROP TABLE IF EXISTS `tab_atelier`;
CREATE TABLE `tab_atelier` (
  `id_atelier` int(11) NOT NULL AUTO_INCREMENT,
  `date_atelier` date NOT NULL,
  `heure_atelier` varchar(25) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `duree_atelier` int(11) NOT NULL DEFAULT '0',
  `anim_atelier` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `id_sujet` int(5) NOT NULL DEFAULT '0',
  `nbplace_atelier` int(11) NOT NULL DEFAULT '0',
  `public_atelier` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `statut_atelier` int(11) NOT NULL,
  `salle_atelier` int(11) NOT NULL,
  `tarif_atelier` int(11) NOT NULL,
  `status_atelier` enum('0','1','2') COLLATE latin1_general_ci NOT NULL,
  `cloturer_atelier` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_atelier`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_atelier` VALUES ('9','2015-08-25','12:00','30','21','93','5','Tous public','0','2','1','0','0');
INSERT INTO `tab_atelier` VALUES ('10','2015-09-02','14:30','30','21','65','9','Tous public','0','1','1','0','0');
INSERT INTO `tab_atelier` VALUES ('11','2015-08-25','14:30','60','22','57','8','Tous public','0','3','1','0','0');


DROP TABLE IF EXISTS `tab_atelier_categorie`;
CREATE TABLE `tab_atelier_categorie` (
  `id_atelier_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `label_categorie` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_atelier_categorie`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_atelier_categorie` VALUES ('1','G&eacute;n&eacute;ral');
INSERT INTO `tab_atelier_categorie` VALUES ('2','Bureautique');
INSERT INTO `tab_atelier_categorie` VALUES ('3','Syst&egrave;me d''exploitation');
INSERT INTO `tab_atelier_categorie` VALUES ('4','Imagerie num&eacute;rique');
INSERT INTO `tab_atelier_categorie` VALUES ('5','Internet, web');
INSERT INTO `tab_atelier_categorie` VALUES ('6','Messagerie');
INSERT INTO `tab_atelier_categorie` VALUES ('7','Vid&eacute;o');
INSERT INTO `tab_atelier_categorie` VALUES ('8','Jeunesse');


DROP TABLE IF EXISTS `tab_atelier_sujet`;
CREATE TABLE `tab_atelier_sujet` (
  `id_sujet` int(11) NOT NULL AUTO_INCREMENT,
  `label_atelier` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `content_atelier` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `ressource_atelier` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `niveau_atelier` int(2) NOT NULL,
  `categorie_atelier` int(2) NOT NULL,
  PRIMARY KEY (`id_sujet`)
) ENGINE=MyISAM AUTO_INCREMENT=162 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_atelier_sujet` VALUES ('14','Internet : lire la vidéo et la musique','Ecouter-voir sur internet, installer les logiciels nécessaires\n','tutoriel et adresses internet fournis','3','5');
INSERT INTO `tab_atelier_sujet` VALUES ('13','Photo : Picasa 2nd partie','Création montages photos et vidéos avec le logiciel de Google.\n','tutoriel fourni','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('9','Bureautique : insérer les images dans le texte','illustrez des textes avec les images, paramétrez l''affichage et l''impression des images.\n','tutoriel et exercices fournis','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('8','Bureautique : les bases de la composition ','Mise en page rapide d''un document, méthodologie des outils à votre disposition.\n   <br><br> \n    *  prise en main du traitement de texte ;   <br><br> \n\n    * sélection d�??informations (textes, images�?�) sur la toile afin de les utiliser dans le document ;   <br><br> \n\n    * mise en forme des informations dans le traitement de texte et mise en page du document.','tutoriel et exercices fournis','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('7','Internet : les outils de Google','googleDocs, googleMaps, googleReader, appréhendez le WEB 2.0\n','tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('5','Courriel : gérer les pièces jointes','envoyer/recevoir une pièce jointe\nenregistrer et conserver les images en pièces jointes','tutoriel fourni','2','6');
INSERT INTO `tab_atelier_sujet` VALUES ('1','Internet : la recherche','Comment trouver ce que l''on recherche sur la toile.','','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('2','Internet : le navigateur','Exploitez les ressources de votre logiciel de surf favori. Découvrez les plugins !','','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('3','Courriel : le webmail','Exploitez au mieux les ressources de votre messagerie sur internet.','','2','6');
INSERT INTO `tab_atelier_sujet` VALUES ('4','Courriel : Utilisez Thunderbird','découvrez un logiciel libre qui gère facilement votre messagerie. Paramétrez votre compte, envoyez et recevez des messages.','','2','6');
INSERT INTO `tab_atelier_sujet` VALUES ('135','Découverte : Ubuntu','Linux pour les débutants ! Testez, pratiquez l''ordinateur comme un windows mais avec linux. Deux ateliers pour découvrir les possibilités d''un autre système d''exploitation.','Tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('6','Internet : Web 2.0','Qu''est-ce que c''est ? Comment l''utiliser, découverte de quelques services intéressants.\n','adresses internet sur signets','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('130','Bureautique : Impress créer un diaporama','Créez votre diaporama, mettez les effets visuels et la musique que vous voulez !','Tutoriel fourni avec des images','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('11','Manipulation : Le copier-coller','utiliser les 4 façons de faire (souris, clavier, glisser-déposer, raccourcis,....)\n','tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('27','Protéger son ordinateur','les manipulations de base pour l''antivirus et la sauvegarde par gravure ou sur matériel externe. Comprendre la propagation d''un virus, en détecter les effets, et quelques pistes pour éradiquer l''infec','','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('28','Internet : Acheter sur internet','petit guide et recommandations de base pour faire ses courses sans danger.','','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('29','Le contrôle parental','Les enfants grandissent : comment les protéger des  contenus dangereux tout en leur permettant de faire des recherches sur internet ? Un exposé sur les solutions actuelles et comment les installer fac','','2','1');
INSERT INTO `tab_atelier_sujet` VALUES ('30','Internet : Les extensions du navigateur','les plug-in, regarder de la vidéo sur internet, java, addons, qu''est-ce? est-ce indispensable ?','','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('31','Découvrir la lecture sur l''ordinateur','Quelles sont les ressources disponibles en ligne et comment optimiser l''ordinateur pour un confort de lecture (à destination des personnes malvoyantes par exemple).','','1','1');
INSERT INTO `tab_atelier_sujet` VALUES ('32','Création de noël : créer une carte de voeux','Créer une carte de v�?ux personnalisée en 2 étapes consécutives.\nAttention inscription obligatoire aux 2 dates de l''atelier','','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('33','Bureautique : Faire une présentation avec Impress','Créez votre présentation quasi professionnel et découvrez les outils du logiciel Impress.','Tutoriel Fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('34','Retouche photo : Les bases','Le B-A-BA : les couleurs, la notion de pixel, l''impression des images, le redimensionnement pour internet,....','','2','4');
INSERT INTO `tab_atelier_sujet` VALUES ('35','Utiliser un scanner','Scanner un document en utilisant le logiciel adapté, comment maitriser les options du logiciel.','','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('36','Photo : Enlever les yeux rouges','Améliorer un document photo : trop sombre, trop clair, yeux rouges, ....','','2','4');
INSERT INTO `tab_atelier_sujet` VALUES ('37','Retouche photo avancée','enlever les défauts (fil électrique, rides trop prononcées, taches....)\nUtilisation de l''outil tampon.','','2','4');
INSERT INTO `tab_atelier_sujet` VALUES ('38','Internet : Les flux RSS','Découvrez l''info en direct, utilisez google Reader ou un logiciel pour vous tenir informé en permanence.','','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('39','Courriel : Envoyez vos images sur internet','Redimensionner, compresser, réduire les images d''un APN pour qu''elle soient jointes dans un email.','','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('40','Windows : l''enregistrement','Comment enregistre-t-on ou télécharge-t-on un document sur l''ordinateur ou sur la clef usb ?\nLa mémorisation en 3 clic !','','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('41','Windows : manipuler les fenêtres','Travailler avec plusieurs fenêtres, retrouver son document de travail, raccourcis clavier pour simplifier les manipulations...','tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('42','Courriel : utiliser les filtres','Redirection de messages, dossiers et classement des mails, laissez le logiciel le faire à votre place !','','2','6');
INSERT INTO `tab_atelier_sujet` VALUES ('43','Windows : Stockage des données','Retour sur l''enregistrement et la prise en charge des supports externes (clef, réseau, disque, etc...)','','1','3');
INSERT INTO `tab_atelier_sujet` VALUES ('44','Windows : la gestion des fichiers','C''est quoi ce ".doc" ? Tout sur les fichiers et les problèmes de compatibilité, la recherche de documents.','','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('45','Internet : Google Blogger','Créez votre blog en 1 clic grâce à votre adresse Gmail','','3','5');
INSERT INTO `tab_atelier_sujet` VALUES ('46','Windows : gérer les dossiers','A quoi ça sert un dossier ? Les clefs du classement réussi et efficace. La recherche de documents windows','','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('47','Bureautique : les tableaux dans Writer','Les aspects de la composition et du logiciel pour traiter le texte','','1','2');
INSERT INTO `tab_atelier_sujet` VALUES ('48','Windows : le téléchargement des documents','Toute la procédure pour ne rien perdre en route !','','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('49','Photo : Picasa 1er partie','Prise en main du logiciel, ses points forts et ses limites','tutoriel fourni','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('50','Photo : PhotoFiltre, 1ère partie','Prise en main du logiciel, les principaux outils','tutoriels','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('51','Photo : PhotoFiltre, 2nd partie','Comment redimensionner une image avec Photofiltre pour l''envoyer ensuite sur internet','','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('52','GIMP : prise en main','Les outils de gimp,ses fenêtres, premières manipulations dans le logiciel de retouche photo.','','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('53','GIMP : Les calques','Découvrez la puissance des calques et leurs usages particuliers. Maitrisez les effets de retouche photo dans le détail !','','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('54','GIMP : L''outil Tampon','Le tampon retoucheur sert à cloner une portion d''image pour reboucher un trou ou un défaut ailleurs sur une photo. Découvrez les trucs pour manier facilement cet outil puissant.','tutoriel','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('55','GIMP : couleur, lumière et ombres','Découvrez les recettes express de retouche photo pour redonner du punch à vos photos !','','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('56','GIMP : les extensions du logiciel','Où trouver de magnifiques pinceaux (brush) gratuits et libres, des patterns, et les tutoriels qui vont avec ! Du matériau pour la création graphique','','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('57','Courriel : La gestion des contacts','Découvrez le carnet d''adresse, comment organiser ses contacts\nou comment les synchroniser avec son portable.','','2','6');
INSERT INTO `tab_atelier_sujet` VALUES ('58','Bureautique : faire une table des matières','Utilisez le traitement de texte pour rédiger un document et regroupez vos idées ! Découvrez comment créer la table des matières avec les styles.','tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('59','Bureautique : Rédiger une lettre','Les règles de composition appliquées à la lettre. Utilisation des styles de paragraphe et des modèles.','tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('60','Windows : le panneau de configuration','Pour tout savoir des paramétrages intimes de votre système d''exploitation.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('61','Windows : maintenance de l''ordinateur','Effectuez chaque mois les sauvegardes et le nettoyage pour que votre ordinateur reste en bonne santé. Toutes les manipulations de base.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('62','Internet : la navigation avec les onglets','Aller de pages en pages, utiliser les outils de navigation au mieux.','tutoriel fourni','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('63','Windows : mettre les photos sur l''ordinateur','Manipuler les fenêtres et maitriser le passage de l''usb au disque dur','tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('64','Bureautique : faire ses comptes avec un tableur','Manipuler le tableur CALC d''OpenOffice pour apprendre à faire ses comptes sur un ordinateur. Les principales fonctions mathématiques.','Tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('65','Bureautique : faire des graphiques avec un tableur','Réaliser de beaux graphiques, les personnaliser et comment en choisir les paramètres.','Tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('66','Windows : Sécuriser son PC','Apprendre les techniques de bases pour sécuriser l''ordinateur : partitionnement, comptes utilisateurs, choix de l''antivirus, mettre en place les bons outils.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('67','Windows : enlever les virus','Votre PC est infesté. Que faire pour s''en débarrasser ? Un petit guide des procédures d''urgence.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('68','Internet : Forums et réseaux sociaux','Une information sur les types réseaux disponibles et sur les procédures d''utilisation/inscription aux forums.','Tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('69','Vidéo : les bases de la manipulation des vidéos','Explication des Codecs et des logiciels nécessaires à la vidéo. Un petit guide de débutant en compression vidéo.','tutoriel fourni','3','7');
INSERT INTO `tab_atelier_sujet` VALUES ('70','Vidéo : Montage avec VirtualDub','Explication du fonctionnement du logiciel, petit montage avec paroles et musique.','ressources et tutoriel fourni','3','7');
INSERT INTO `tab_atelier_sujet` VALUES ('71','Bureautique : les styles dans le traitement de texte','Maitrisez la puissance des styles pour formater rapidement un gabarit et le reproduire à l''infini.','','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('72','Windows : trucs et astuces','Des trucs, des astuces de tous les jours, de petites manipulations qui rendent les procédures moins complexes.','','1','1');
INSERT INTO `tab_atelier_sujet` VALUES ('73','CyberDefi','cyberdefi','','1','1');
INSERT INTO `tab_atelier_sujet` VALUES ('74','Bureautique : Ecrire CV et lettre de motivation','Tout savoir sur les styles pour agrémenter votre CV. Les formats à envoyer sur internet, les formats pour imprimer.','','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('75','Bureautique : Faire un calendrier personnalisé','Maniez le traitement de texte pour réaliser un beau calendrier ou utiliser un logiciel approprié !','','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('76','Decouverte Logiciel : Célestia','Découvrez l''astronomie et baladez-vous dans les étoiles avec Célestia, logiciel libre de navigation astronomique.','Tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('77','Découverte : Evernote','Souvenez-vous de tout grâce à cet utilitaire de prise de note sur internet.','tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('78','Découverte logiciel : Homebank','Gérez vos comptes grâce à Homebank, spécialiste des comptes bancaires, import des listings de votre banque, création de statistiques.','tutoriel','3','9');
INSERT INTO `tab_atelier_sujet` VALUES ('79','Découverte : GoogleMaps','Baladez vous dans les rues avec streetMap, calculez un itinéraire...géolocalisez vos images...','tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('80','Découverte : Netvibes','Restez au courant de tout ce que vous aimez avec Netvibes qui permet de regrouper tous les liens, les sites que vous suivez.','tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('81','Découverte Logiciel : MyFamilyTree','Généalogie : créez l''arbre de votre famille.','tutoriel','3','9');
INSERT INTO `tab_atelier_sujet` VALUES ('82','Découverte Logiciel : Opera','Le célèbre navigateur venu du Mac propose une ergonomie à la pointe, essayez-le !','tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('83','Découverte : Deezer/Jamendo la musique en ligne','Découvrez ces services de musique en ligne, pour écouter de partout !','tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('84','Découverte : Pickmonkey','Site de retouche photo en ligne, simplicité et efficacité !!','tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('85','Découverte Logiciel : SweetHome3D','Modélisez votre intérieur, testez les volumes...votre maison en 3D facile !','tutoriel','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('86','Manipulation : Où conserver ses favoris ?','Tous les moyens pour aller rapidement d''un site à l''autre et d''en conserver la trace.','tutoriel','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('87','Manipulation : l''enregistrement','Des exercices pour maitriser la procédure, les options pour créer des documents efficacement.','tutoriel','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('88','Windows : l''Arborescence','Découvrez et manipulez les dossiers de Windows grâce à l''arborescence','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('89','Internet : Utiliser les forums','Sélection, inscription, utilisation du forum en toute simplicité.','Tutoriel fourni','3','5');
INSERT INTO `tab_atelier_sujet` VALUES ('90','Internet : trouver son voyage','Choisir le bon séjour et utiliser les comparateurs pour ne pas être déçu du voyage !','tutoriel fourni','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('91','Manipulation : paramétrer son bureau','changer un fond d''écran, faire apparaître les icônes, mettre un lanceur d''applications, la mise en veille et gestion de la batterie etc...Les paramétrages de bases pour bien utiliser son bureau.','tutoriel fourni','1','3');
INSERT INTO `tab_atelier_sujet` VALUES ('92','Manipulation : Faire du PDF','Comment réaliser un document sécurisé, dont le format soit reconnu par tous les ordinateurs et qui passe facilement en pièce jointe ? Faites du PDF ! Découvrez les fonctionnalités pratiques de ce format.','tutoriel fourni','1','2');
INSERT INTO `tab_atelier_sujet` VALUES ('93','Atelier Vacances : Relooke-toi !','Se relooker sur internet grace au site de TAAZ','','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('94','Atelier Vacances : POSTIT WAR','Transformer des images en grille à postit puis créer sur l''epn','','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('19','Découverte logiciel : SKYPE','Présentation des fonctionnalités du célèbre logiciel de téléphonie par ordinateur.','Tutoriel fourni','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('18','Manipulation : Imprimer','Comment imprimer depuis internet ? diverses façons de correctement imprimer un document ou une page internet.','Tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('17','Atelier Vacances :  Vidéo Jibjab','Viens incarner DarkVador ou Luke SkyWalker sur le site de JibJab, envoie ta vidéo à tes copains !','Photo finish !','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('16','Atelier Vacances : Carte de Fête des mères','Réalise sur un joli papier une carte personnalisée pour ta maman ou ton papa avec des photos et un texte de ta main.','','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('15','Atelier Vacances : Crée ton super Héros','Viens à la médiathèque créer ton personnage de BD Comics.','','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('100','Spécial GD Eté','5 séances pour se former ou perfectionner à Windows :\n1. Les bases du système d�??exploitation\n2. Notion de �??dossier�?�\n3. Notion d�?? �??enregistrement�?�\n4. Manipulation des fenêtres\n5. Ranger ses documents','Tutoriels et autoformation','1','3');
INSERT INTO `tab_atelier_sujet` VALUES ('101','Spécial Photo Eté','5 Séances de retouche photo Photoshop / Gimp\n1. Prise en main de l�??interface (Détail sur la palette des calques)\n2. L�??outil de sélection plume (manipulation des courbes de Béziers)\n3. Où l�??on apprend à faire voler les objets\n4. Tout sur la couleur (palettes, calques de fusion, tonalités)\n5. Au choix : �?tude de cas / Questions-Réponses','tutoriels et autoformation','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('102','Internet : paramétrer le navigateur','Mettre la sécurité sur la navigation c''est trop important : tout sur les cookies, les mots de passe, la navigation privée.','Tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('103','cCleaner : partie 1','Découvrez la puissance du logiciel : en détail le nettoyeur et la base de registre.','Tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('104','cCleaner : partie 2','Suite avec le détail sur les options, les outils et les paramétrages.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('105','Bureautique : Débuter le traitement de texte','Les manipulations de base pour se servir d''un traitement de texte, à quoi servent les menus, la conception d''un document','tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('106','Bureautique : Débuter le tableur','Bien commencer avec une feuille de calcul, les manipulations de bases pour comprendre le fonctionnement d''un tableur : les cases, les menus, la composition du document.','Tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('107','Bureautique : Les statistiques','Comment construire ses statistiques, conception de formules, conception des graphiques pour les tableaux croisés dynamiques.','tutoriel fourni avec exemples','3','2');
INSERT INTO `tab_atelier_sujet` VALUES ('108','Bureautique : Manipulations du traitement de texte ','Caractères spéciaux, casse, en-têtes et pied-de-page, commentaires, paramétrages particuliers de documents : page d''en-tête, etc...plein d''astuces pour connaitre plus en profondeur le traitement de texte.','tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('109','Bureautique :  Règles de mise en page et impression','Conception du document pour l''impression dans le tableur et le traitement de texte. Les exportations au format PDF, les conseils de base pour s''éviter les réimpressions couteuses.','tutoriel fourni','2','2');
INSERT INTO `tab_atelier_sujet` VALUES ('110','Découverte logiciel : Scribus','La puissance d''un outil de composition éditorial en licence libre. Pour faire du maquettisme comme dans les journaux !','tutoriel fourni','3','2');
INSERT INTO `tab_atelier_sujet` VALUES ('111','Découverte logiciel : Winamp','Ecoutez votre musique partout avec Winamp et ses alternatives libres. Comment utiliser le logiciel et se créer des playlists facilement.','tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('112','Découverte : Linux','Essayez un système d''exploitation concurrent de Windows, libre et gratuit. Vous pourriez être surpris !','Cdrom de démonstration founi ainsi que conseils de démarrage.','1','9');
INSERT INTO `tab_atelier_sujet` VALUES ('113','Windows : les Utilisateurs','Créez votre profil et protégez vos données, tout sur les droits utilisateurs dans windows.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('114','Windows : Installer un périphérique','Installer une nouvelle imprimante, brancher un écran supplémentaire, relier en blutooth un téléphone portable, etc...','Tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('115','Windows : configurer son réseau WIFI','Comprendre le fonctionnement et les paramétrages dans Windows, les options de votre abonnement internet BOX.','Tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('116','Windows : gérer les programmes','Faire les mises à jour, désinstaller, trier et mettre les raccourcis vers les programmes les plus utilisés.','tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('117','Windows : Installer les programmes','Téléchargez et installez les programmes de votre choix : la procédure complète.','tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('118','Découverte : GMail, Agenda, Photos','2e volet des services google : des complémentaires au quotidien qui font partie de Google+','tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('119','Découverte : GoogleDrive','3e volet des services Google : la gestion des documents en ligne. Création de lettres, de présentations de feuilles de calcul.','tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('120','Découverte : GooglePlay et Youtube','4e volet des services Google : les applications pour smartphone et la gestion des ressources vidéos en ligne.','tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('121','Découverte : les services Google','Découvrez l''étendue des services proposés par Google. ','','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('122','Windows : la gestion du Disque Dur','Partitionnez, sauvegardez, cryptez vos données !','','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('123','Maintenance : Les sauvegardes','Un panel des pratiques simples pour sauvegarder en toute sécurité ses documents et son système d�??exploitation.','Tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('124','Maintenance : Les mises à jour indispensables','Les clés pour maintenir son système et ses applications à jour en l�??automatisant.','Tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('125','Maintenance : Installer-désinstaller les programmes','Choisir, installer désinstaller, adoptez les bons réflexes pour éviter les publicités et la pollution de votre ordinateur. Découvrez les utilitaires pour faire le ménage sans risque !','Tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('126','Maintenance : Les bonnes pratiques d''internet','Le basique d�??une utilisation correcte et sans risque d�??Internet : la sécurité du navigateur, les applications pour éviter les publicités.','Tutoriel fourni','2','3');
INSERT INTO `tab_atelier_sujet` VALUES ('127','Découverte : Android','Vous possédez un smartphone ou une tablette mais n�??en avez pas compris toutes les fonctionnalités ? Amenez votre matériel pour les 2 séances pour comprendre les réglages de base, les applications, la sécurité du système.','Tutoriel fourni','1','3');
INSERT INTO `tab_atelier_sujet` VALUES ('128','Photo : Gérer les images','Quel logiciel utiliser pour les visionner, les trier, les imprimer ? Découvrez la gestion en ligne ou sur l�??ordinateur.','Tutoriel fourni','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('129','Photo : Mettre les photos sur l''ordinateur','Comment passer de l�??appareil photo à l�??ordinateur simplement et en quelques exercices efficaces.','Tutoriel fourni','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('131','Découverte : Gmail la messagerie selon Google','Découvrez ce service en détail parmi les nombreux autres proposés par Google. Comment s�??en servir, optimiser et utiliser sur plusieurs supports.','Tutoriel fourni','1','6');
INSERT INTO `tab_atelier_sujet` VALUES ('132','Découverte : Photos+, le gestionnaire en ligne de photos','Découvrez ce service en détail parmi les nombreux autres proposés par Google. Comment s�??en servir, optimiser et utiliser sur plusieurs supports.','Tutoriel fourni','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('133','Bureautique : Découverte du tableur','Prise en main du logiciel Calc, concepts de base, calculs de base\n','Tutoriel et exercices fournis','1','2');
INSERT INTO `tab_atelier_sujet` VALUES ('136','Découverte logiciel : Windows Movie Maker','2 ateliers pour utiliser et créer de petits montages vidéos personnalisés.','Tutoriel fourni','2','7');
INSERT INTO `tab_atelier_sujet` VALUES ('137','Manipulation : Créer un disque de sauvegarde','Créez vous-même une sauvegarde de votre ordinateur grâce à un DVD ou une clef Usb pour le stockage.','Tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('138','Manipulation : utiliser les raccourcis clavier','Découvrez toute la puissance des raccourcis clavier et manipulez par des exercices simples.','Tutoriel fourni','1','3');
INSERT INTO `tab_atelier_sujet` VALUES ('139','Atelier Vacances : Chasse au trésor','Découvre google earth à travers une chasse au trésor. Une carte, des indices, viens avec des amis !','','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('140','Atelier Vacances : La photocabine','Se tirer le portrait façon photomaton avec des effets rigolos !','Tutoriel fourni','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('141','Atelier Vacances : QRcode personnalisé','Créé ton QRcode pour faire passer tes infos. a intégrer dans facebook ou sur ton blog !','Tutoriel fourni','1','8');
INSERT INTO `tab_atelier_sujet` VALUES ('142','Retouche Photo : Technique du Tilt-shift','Effet de flou et utilisation du mode masque','Tutoriel fourni','2','4');
INSERT INTO `tab_atelier_sujet` VALUES ('143','Retouche photo : Faire voler les personnages','Prise de vue et technique de retouche : utilisation du masque de calque','Tutoriel fourni','1','4');
INSERT INTO `tab_atelier_sujet` VALUES ('144','Retouche photo : Faire un pèle-mèle','Pèle mèle créatif avec des photos et de l''intégration de brosses et de motifs.','Tutoriel fourni','2','4');
INSERT INTO `tab_atelier_sujet` VALUES ('145','Retouche photo : Rephotographie','Prise de vue et montage de photo replacées dans leur contexte historique.','Tutoriel fourni','3','4');
INSERT INTO `tab_atelier_sujet` VALUES ('146','Bureautique : Faire des cartes de voeux','Choisir le papier, le format mettre les images, les décors puis imprimer !','Tutoriel fourni','1','2');
INSERT INTO `tab_atelier_sujet` VALUES ('147','Maintenance : nettoyer le PC','Les logiciels et les manipulations pour nettoyer le PC correctement.','Tutoriel fourni','3','3');
INSERT INTO `tab_atelier_sujet` VALUES ('148','Découverte : PInterest','Tableaux d''images sur internet et gestion de liens','Tutoriel fourni','1','9');
INSERT INTO `tab_atelier_sujet` VALUES ('149','Découverte logiciel : Keepass','Gérer efficacement ses mots de passe. Un utilitaire tout en un pour la sécurité !','Tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('150','Découverte logiciel : Photorécit','Comme windows Movie Maker, un logiciel dédié au montage de photos et à leur sonorisation.','Tutoriel fourni','2','9');
INSERT INTO `tab_atelier_sujet` VALUES ('151','Maintenance : scanner et defragmenter ','Utiliser au mieux l''espace de son disque dur : les outils pour le nettoyer et partitionner.','Tutoriel fourni','2','1');
INSERT INTO `tab_atelier_sujet` VALUES ('152','Photo : envoyer/partager les photos','Envoi en pièce jointe ou compte en ligne, découvrez les moyens de partager efficacement vos photos en toute sécurité.','Tutoriel fourni','2','4');
INSERT INTO `tab_atelier_sujet` VALUES ('153','Internet : la sécurité','Pratiques, sécurisation des transactions, paramétrages du navigateur, les clefs pour une navigation en toute sécurité.','Tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('154','Découverte : la logithèque idéale','Tous les logiciels dont vous pouvez avoir besoin au quotidien. Gratuits, à licence libre ou propriétaire, découvrez les nouveaux logiciels et les interfaces web.','Tutoriel fourni','1','1');
INSERT INTO `tab_atelier_sujet` VALUES ('155','Manipulation : La sélection','Toutes le façon de sélectionner un texte ou une image avant d''effectuer le copier-coller, de déplacer ou de supprimer.','Tutoriel fourni','1','1');
INSERT INTO `tab_atelier_sujet` VALUES ('156','Découverte : Google Agenda','L''agenda par google : découvrez l''intéractivité et la simplicité d''utilisation de cet agenda partagé.','Tutoriel fourni','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('157','Internet : La sécurité sur facebook','Sécurisez vos données de réseau social. Les amis de mes amis ne sont pas toujours mes amis.....','Tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('158','Découverte : Dropbox','Le service de partage et de stockage en ligne de vos fichiers','Tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('159','Découverte : Monservicepublic.fr','Créez votre compte pour y mettre en sécurité vos papiers, et accéder facilement aux services proposés par "Monservicepublic.fr"','Tutoriel fourni','2','5');
INSERT INTO `tab_atelier_sujet` VALUES ('160','Découverte : Vide-grenier en ligne','Il n''y a pas que Le bon coin sur internet : découvrez les autres sites qui permettent d''échanger les objets du quotidien sur internet.','Tutoriel fourni','1','5');
INSERT INTO `tab_atelier_sujet` VALUES ('161','Découverte : Flickr','Le site de partage et de stockage des images sur internet par Yahoo!','Tutoriel fourni','2','5');


DROP TABLE IF EXISTS `tab_city`;
CREATE TABLE `tab_city` (
  `id_city` int(11) NOT NULL AUTO_INCREMENT,
  `nom_city` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `code_postale_city` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pays_city` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_city`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_city` VALUES ('1','Montargis','45200','FRANCE');
INSERT INTO `tab_city` VALUES ('2','Paris','75000','France');
INSERT INTO `tab_city` VALUES ('3','Tombouctou','10878','France');


DROP TABLE IF EXISTS `tab_computer`;
CREATE TABLE `tab_computer` (
  `id_computer` int(11) NOT NULL AUTO_INCREMENT,
  `nom_computer` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `comment_computer` text COLLATE latin1_general_ci NOT NULL,
  `os_computer` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `usage_computer` int(11) NOT NULL DEFAULT '0',
  `fonction_computer` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `id_salle` int(11) NOT NULL,
  `adresse_mac_computer` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `adresse_ip_computer` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nom_hote_computer` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `date_lastetat_computer` date NOT NULL,
  `lastetat_computer` mediumint(11) NOT NULL,
  `configurer_epnconnect_computer` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_computer`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_computer` VALUES ('1','poste 01','','Windows 8','1','','2','','','','2015-01-13','0','1');
INSERT INTO `tab_computer` VALUES ('2','poste 02','','Windows 8','1','','2','','','','2014-11-25','0','1');
INSERT INTO `tab_computer` VALUES ('3','poste 03','','Windows 8','1','','2','','','','2014-11-25','0','1');
INSERT INTO `tab_computer` VALUES ('4','poste 04','','Windows Vista','1','','2','','','','2014-11-04','0','1');
INSERT INTO `tab_computer` VALUES ('5','poste 05','','Windows 8','1','','2','','','','2014-11-04','0','1');
INSERT INTO `tab_computer` VALUES ('16','Test 1','','Windows 7','1','','3','','','','0000-00-00','0','');
INSERT INTO `tab_computer` VALUES ('7','Consultation 1','','Windows 8','1','8','1','','','','2015-03-26','0','1');
INSERT INTO `tab_computer` VALUES ('8','Consultation 2','','Windows 8','1','8','1','','','','2015-03-26','0','1');
INSERT INTO `tab_computer` VALUES ('9','Consultation 3','','Windows 8','1','','1','','','','2015-03-26','0','1');
INSERT INTO `tab_computer` VALUES ('10','Consultation 4','','Windows 8','1','8','1','','','','2015-03-26','0','1');
INSERT INTO `tab_computer` VALUES ('17','Test 2','','Windows 7','1','','3','','','','0000-00-00','0','');
INSERT INTO `tab_computer` VALUES ('13','poste Admin','','Windows Vista','2','0','1','','','','0000-00-00','0','1');
INSERT INTO `tab_computer` VALUES ('14','Admin rouge','','Ubuntu','2','0','2','','','','0000-00-00','0','1');
INSERT INTO `tab_computer` VALUES ('15','poste impression','poste scanner et imprimante','Windows Vista','3','','1','','','','0000-00-00','0','1');


DROP TABLE IF EXISTS `tab_config`;
CREATE TABLE `tab_config` (
  `id_config` int(11) NOT NULL AUTO_INCREMENT,
  `activer_console` int(11) NOT NULL,
  `name_config` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `unit_default_config` int(2) NOT NULL,
  `unit_config` int(2) NOT NULL,
  `maxtime_config` int(11) NOT NULL,
  `maxtime_default_config` int(11) NOT NULL,
  `inscription_usagers_auto` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  `message_inscription` text COLLATE latin1_general_ci NOT NULL,
  `id_espace` int(11) NOT NULL,
  `nom_espace` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `activation_forfait` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  `resarapide` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  `duree_resarapide` int(11) NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_config` VALUES ('1','1','0.9','15','10','240','120','1','','1','Epn du Lac','1','1','60');
INSERT INTO `tab_config` VALUES ('2','1','0.9','15','5','120','120','1','','2','TEST EPN','1','0','0');


DROP TABLE IF EXISTS `tab_config_logiciel`;
CREATE TABLE `tab_config_logiciel` (
  `id_config_logiciel` int(11) NOT NULL AUTO_INCREMENT,
  `id_espace` int(11) NOT NULL,
  `config_menu_logiciel` int(11) NOT NULL,
  `page_inscription_logiciel` int(11) NOT NULL,
  `page_renseignement_logiciel` int(11) NOT NULL,
  `connexion_anim_logiciel` int(11) NOT NULL,
  `bloquage_touche_logiciel` int(11) NOT NULL,
  `affichage_temps_logiciel` int(11) NOT NULL,
  `deconnexion_auto_logiciel` int(11) NOT NULL,
  `fermeture_session_auto` int(11) NOT NULL,
  PRIMARY KEY (`id_config_logiciel`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_config_logiciel` VALUES ('1','1','0','1','1','0','1','1','1','1');
INSERT INTO `tab_config_logiciel` VALUES ('2','2','0','1','0','0','1','1','1','1');


DROP TABLE IF EXISTS `tab_connexion`;
CREATE TABLE `tab_connexion` (
  `id_connexion` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `date_cx` datetime NOT NULL,
  `type_cx` int(11) NOT NULL,
  `macasdress_cx` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `navigateur_cx` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `system_cx` varchar(200) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_connexion`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_connexion` VALUES ('1','1','2015-10-01 22:00:45','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('2','1','2015-10-01 22:08:46','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('3','1','2015-10-01 22:26:53','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('4','1','2015-10-01 22:27:07','2','0','0','0');
INSERT INTO `tab_connexion` VALUES ('5','1','2015-10-06 21:25:28','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('6','1','2015-10-06 21:28:36','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('7','1','2015-10-08 21:29:38','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('8','1','2015-10-11 16:27:46','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('9','1','2015-10-11 16:31:20','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('10','1','2015-10-11 16:31:40','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('11','1','2015-10-11 16:32:38','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('12','1','2015-10-11 16:32:44','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('13','1','2015-10-11 16:33:22','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('14','1','2015-10-11 16:34:13','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('15','1','2015-10-11 16:35:00','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');
INSERT INTO `tab_connexion` VALUES ('16','1','2015-10-11 16:36:35','1','inconnue pour l''instant','Mozilla Firefox 41.0','Linux - Ubuntu');


DROP TABLE IF EXISTS `tab_csp`;
CREATE TABLE `tab_csp` (
  `id_csp` int(11) NOT NULL AUTO_INCREMENT,
  `csp` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_csp`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_csp` VALUES ('1','Retrait?');
INSERT INTO `tab_csp` VALUES ('2','Employ�');
INSERT INTO `tab_csp` VALUES ('3','Scolaire');
INSERT INTO `tab_csp` VALUES ('4','Demandeur d''emploi');
INSERT INTO `tab_csp` VALUES ('5','M&egrave;re/P&egrave;re au foyer');
INSERT INTO `tab_csp` VALUES ('6','Lyc?en');
INSERT INTO `tab_csp` VALUES ('7','Etudiant');
INSERT INTO `tab_csp` VALUES ('8','Artisans/Prof. Lib');
INSERT INTO `tab_csp` VALUES ('9','Instituteurs');
INSERT INTO `tab_csp` VALUES ('10','Agriculteur');
INSERT INTO `tab_csp` VALUES ('11','Fonctionnaires');
INSERT INTO `tab_csp` VALUES ('12','Divers');
INSERT INTO `tab_csp` VALUES ('13','Coll?gien');
INSERT INTO `tab_csp` VALUES ('14','Non renseign�e');
INSERT INTO `tab_csp` VALUES ('15','Professions interm�diaires');
INSERT INTO `tab_csp` VALUES ('16','Ouvrier');
INSERT INTO `tab_csp` VALUES ('17','Cadres ');


DROP TABLE IF EXISTS `tab_days_closed`;
CREATE TABLE `tab_days_closed` (
  `id_days_closed` int(11) NOT NULL AUTO_INCREMENT,
  `year_days_closed` int(4) NOT NULL,
  `num_days_closed` int(3) NOT NULL,
  `state_days_closed` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `id_epn` int(11) NOT NULL,
  PRIMARY KEY (`id_days_closed`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_days_closed` VALUES ('1','2015','194','F','1');


DROP TABLE IF EXISTS `tab_espace`;
CREATE TABLE `tab_espace` (
  `id_espace` int(11) NOT NULL AUTO_INCREMENT,
  `nom_espace` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_city` int(11) NOT NULL,
  `adresse` varchar(300) COLLATE latin1_general_ci NOT NULL,
  `tel_espace` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `fax_espace` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `logo_espace` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `couleur_espace` int(11) NOT NULL,
  PRIMARY KEY (`id_espace`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_espace` VALUES ('1','Epn du Lac','1','45, rue franklin roosevelt','','','','2');
INSERT INTO `tab_espace` VALUES ('2','TEST EPN','3','rue du test','','','','3');


DROP TABLE IF EXISTS `tab_forfait`;
CREATE TABLE `tab_forfait` (
  `id_forfait` int(11) NOT NULL AUTO_INCREMENT,
  `date_creation_forfait` date NOT NULL,
  `type_forfait` int(11) NOT NULL,
  `nom_forfait` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `prix_forfait` int(11) NOT NULL,
  `critere_forfait` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `commentaire_forfait` text COLLATE latin1_general_ci NOT NULL,
  `nombre_duree_forfait` int(11) NOT NULL,
  `unite_duree_forfait` int(11) NOT NULL,
  `temps_forfait_illimite` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  `date_debut_forfait` date NOT NULL,
  `status_forfait` int(11) NOT NULL,
  `nombre_temps_affectation` int(11) NOT NULL,
  `unite_temps_affectation` int(11) NOT NULL,
  `frequence_temps_affectation` int(11) NOT NULL,
  `temps_affectation_occasionnel` int(11) NOT NULL,
  `nombre_atelier_forfait` int(11) NOT NULL,
  PRIMARY KEY (`id_forfait`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_forfait` VALUES ('1','2015-06-16','1','2h/jour                               ','1','','Deux heures renouvell�es le lendemain','0','0','1','2015-06-16','1','2','2','1','0','0');
INSERT INTO `tab_forfait` VALUES ('2','2015-07-05','1','10h/sem','5','','10 � gaspiller dans la semaine','0','0','1','2015-07-05','1','10','2','2','0','0');
INSERT INTO `tab_forfait` VALUES ('3','2015-08-08','1','Illimit� ','30','','Consultation illimit�e � l''ann�e','12','3','0','2015-08-08','1','50','2','3','0','0');


DROP TABLE IF EXISTS `tab_horaire`;
CREATE TABLE `tab_horaire` (
  `id_horaire` int(11) NOT NULL AUTO_INCREMENT,
  `jour_horaire` int(1) NOT NULL,
  `hor1_begin_horaire` int(4) NOT NULL,
  `hor1_end_horaire` int(4) NOT NULL,
  `hor2_begin_horaire` int(4) NOT NULL,
  `hor2_end_horaire` int(4) NOT NULL,
  `unit_horaire` int(3) NOT NULL,
  `id_epn` int(3) NOT NULL,
  PRIMARY KEY (`id_horaire`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_horaire` VALUES ('1','1','0','0','0','0','0','1');
INSERT INTO `tab_horaire` VALUES ('2','2','600','720','780','1140','0','1');
INSERT INTO `tab_horaire` VALUES ('3','3','600','720','780','1140','0','1');
INSERT INTO `tab_horaire` VALUES ('4','4','600','720','780','1140','0','1');
INSERT INTO `tab_horaire` VALUES ('5','5','600','720','780','1140','0','1');
INSERT INTO `tab_horaire` VALUES ('6','6','600','720','780','1140','0','1');
INSERT INTO `tab_horaire` VALUES ('7','7','0','0','0','0','0','1');
INSERT INTO `tab_horaire` VALUES ('8','1','0','0','0','0','0','2');
INSERT INTO `tab_horaire` VALUES ('9','2','600','720','780','1140','0','2');
INSERT INTO `tab_horaire` VALUES ('10','3','600','720','780','1140','0','2');
INSERT INTO `tab_horaire` VALUES ('11','4','600','720','780','1140','0','2');
INSERT INTO `tab_horaire` VALUES ('12','5','600','720','780','1140','0','2');
INSERT INTO `tab_horaire` VALUES ('13','6','600','720','780','1140','0','2');
INSERT INTO `tab_horaire` VALUES ('14','7','0','0','0','0','0','2');


DROP TABLE IF EXISTS `tab_inscription_user`;
CREATE TABLE `tab_inscription_user` (
  `id_inscription_user` int(11) NOT NULL AUTO_INCREMENT,
  `date_inscription_user` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `nom_inscription_user` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `prenom_inscription_user` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `sexe_inscription_user` char(1) COLLATE latin1_general_ci NOT NULL,
  `jour_naissance_inscription_user` int(2) NOT NULL,
  `mois_naissance_inscription_user` int(2) NOT NULL,
  `annee_naissance_inscription_user` int(4) NOT NULL,
  `adresse_inscription_user` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `quartier_inscription_user` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `code_postal_inscription` int(5) NOT NULL,
  `commune_inscription_autres` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `ville_inscription_user` int(11) NOT NULL,
  `pays_inscription_user` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `tel_inscription_user` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `tel_port_inscription_user` varchar(18) COLLATE latin1_general_ci NOT NULL,
  `mail_inscription_user` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `temps_inscription_user` int(11) NOT NULL,
  `login_inscription_user` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `pass_inscription_user` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `status_inscription_user` int(2) NOT NULL,
  `lastvisit_inscription_user` date NOT NULL,
  `csp_inscription_user` int(11) NOT NULL,
  `equipement_inscription_user` int(11) NOT NULL,
  `utilisation_inscription_user` int(11) NOT NULL,
  `connaissance_inscription_user` text COLLATE latin1_general_ci NOT NULL,
  `info_inscription_user` text COLLATE latin1_general_ci NOT NULL,
  `id_inscription_computer` int(11) NOT NULL,
  `id_lastvisitespace_inscuser` int(11) NOT NULL,
  PRIMARY KEY (`id_inscription_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_inter`;
CREATE TABLE `tab_inter` (
  `id_inter` int(11) NOT NULL AUTO_INCREMENT,
  `titre_inter` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `comment_inter` text COLLATE latin1_general_ci NOT NULL,
  `statut_inter` tinyint(1) NOT NULL DEFAULT '0',
  `date_inter` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_inter`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_level`;
CREATE TABLE `tab_level` (
  `id_level` tinyint(4) NOT NULL AUTO_INCREMENT,
  `code_level` tinyint(1) NOT NULL DEFAULT '0',
  `nom_level` varchar(80) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_level`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_level` VALUES ('1','1','Debutant');
INSERT INTO `tab_level` VALUES ('2','2','Apprenti');
INSERT INTO `tab_level` VALUES ('3','3','Autonome');
INSERT INTO `tab_level` VALUES ('4','4','Confirm�s');
INSERT INTO `tab_level` VALUES ('5','5','Expert');
INSERT INTO `tab_level` VALUES ('6','6','Administrateur');


DROP TABLE IF EXISTS `tab_logs`;
CREATE TABLE `tab_logs` (
  `id_log` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `log_date` datetime DEFAULT NULL,
  `log_MAJ` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `log_valid` int(11) NOT NULL,
  `log_comment` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_logs` VALUES ('1','bac','2015-03-07 14:56:44','0.8','1','Backup integral de la base effectue');
INSERT INTO `tab_logs` VALUES ('2','maj','2015-03-07 14:56:00','0.9','1','Mise � jour de version 0.9 effectuee');
INSERT INTO `tab_logs` VALUES ('3','adh','2015-04-22 16:57:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('4','adh','2015-04-30 09:15:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('5','adh','2015-04-30 09:27:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('6','adh','2015-04-30 09:29:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('7','adh','2015-04-30 09:30:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('8','adh','2015-04-30 09:41:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('9','adh','2015-05-01 10:30:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('10','adh','2015-05-16 07:24:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('11','maj','2015-05-16 07:26:00','0.95','1','Mise � jour de version 0.95 effectuee');
INSERT INTO `tab_logs` VALUES ('12','adh','2015-05-27 21:20:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('13','adh','2015-06-01 21:56:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('14','adh','2015-06-12 20:51:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('15','adh','2015-06-16 21:49:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('16','adh','2015-07-04 22:24:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('17','adh','2015-07-05 17:55:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('18','adh','2015-07-08 20:28:00','','1','Mise � jour des adhesions adherents du jour');
INSERT INTO `tab_logs` VALUES ('19','adh','2015-07-16 20:55:00','','1','Mise � jour des adhesions adherents du jour');


DROP TABLE IF EXISTS `tab_message_epnconnect`;
CREATE TABLE `tab_message_epnconnect` (
  `id_message` int(11) NOT NULL AUTO_INCREMENT,
  `corp_message` text COLLATE latin1_general_ci NOT NULL,
  `status_message` int(11) NOT NULL,
  `espace_message` int(11) NOT NULL,
  `date_message` date NOT NULL,
  PRIMARY KEY (`id_message`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_messages`;
CREATE TABLE `tab_messages` (
  `id_messages` int(11) NOT NULL AUTO_INCREMENT,
  `mes_date` datetime DEFAULT NULL,
  `mes_auteur` int(11) NOT NULL,
  `mes_txt` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mes_tag` varchar(300) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mes_destinataire` int(11) NOT NULL,
  PRIMARY KEY (`id_messages`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_messages` VALUES ('1','2015-04-02 00:00:00','1','etst','test','0');
INSERT INTO `tab_messages` VALUES ('2','2015-08-21 20:43:35','1','salut','test','0');


DROP TABLE IF EXISTS `tab_news`;
CREATE TABLE `tab_news` (
  `id_news` int(11) NOT NULL AUTO_INCREMENT,
  `titre_news` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `comment_news` text COLLATE latin1_general_ci NOT NULL,
  `visible_news` tinyint(1) NOT NULL DEFAULT '0',
  `type_news` int(11) NOT NULL,
  `date_publish` datetime DEFAULT NULL,
  `date_news` datetime DEFAULT NULL,
  `id_epn` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_news`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_print`;
CREATE TABLE `tab_print` (
  `id_print` int(11) NOT NULL AUTO_INCREMENT,
  `print_date` datetime NOT NULL,
  `print_user` int(11) NOT NULL,
  `print_debit` int(11) NOT NULL,
  `print_tarif` int(11) NOT NULL,
  `print_statut` int(11) NOT NULL,
  `print_credit` decimal(10,2) NOT NULL,
  `print_userexterne` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `print_epn` int(11) NOT NULL,
  `print_caissier` int(11) NOT NULL,
  `print_paiement` int(11) NOT NULL,
  PRIMARY KEY (`id_print`)
) ENGINE=MyISAM AUTO_INCREMENT=448 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_print` VALUES ('1','2015-01-06 13:58:00','198','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('2','2015-01-03 14:00:00','8612','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('3','2015-01-06 14:01:00','92','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('4','2015-01-06 14:13:00','7790','2','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('5','2015-01-06 14:13:00','7790','0','0','2','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('6','2015-01-06 14:14:00','7243','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('7','2015-01-06 14:14:00','7243','4','6','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('8','2015-01-06 14:15:00','7961','15','5','1','2.25','','1','0','0');
INSERT INTO `tab_print` VALUES ('9','2015-01-06 14:16:00','7232','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('10','2015-01-06 14:17:00','249','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('11','2015-01-06 14:17:00','8057','3','6','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('12','2015-01-06 14:18:00','8372','10','5','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('13','2015-01-06 14:18:00','8372','10','6','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('14','2015-01-06 14:19:00','635','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('15','2015-01-06 14:19:00','7402','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('16','2015-01-06 14:20:00','4972','13','5','1','1.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('17','2015-01-06 14:21:00','92','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('18','2015-01-06 14:21:00','92','4','6','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('19','2015-01-06 14:22:00','6979','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('20','2015-01-03 14:23:00','6059','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('21','2015-01-06 14:24:00','165','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('22','2015-01-06 14:24:00','1309','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('23','2015-01-06 14:24:00','8610','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('24','2015-01-06 14:25:00','3085','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('25','2015-01-06 14:25:00','8566','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('26','2015-01-06 14:25:00','4884','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('27','2015-01-06 16:04:00','8610','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('28','2015-01-06 16:07:00','8293','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('29','2015-01-06 16:08:00','8525','12','5','1','1.80','','1','0','0');
INSERT INTO `tab_print` VALUES ('30','2015-01-06 16:08:00','7783','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('31','2015-01-06 16:09:00','8324','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('37','2015-01-07 15:17:00','8485','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('38','2015-01-07 15:25:00','8372','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('34','2015-01-07 14:36:00','5464','20','6','1','6.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('35','2015-01-07 14:39:00','8377','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('36','2015-01-07 14:40:00','8559','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('39','2015-01-07 15:25:00','8372','3','6','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('40','2015-01-07 16:50:00','8536','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('41','2015-01-07 16:53:00','7505','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('42','2015-01-07 16:56:00','7820','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('43','2015-01-07 17:14:00','8138','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('44','2015-01-07 17:34:00','7','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('45','2015-01-08 15:01:00','8466','3','6','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('46','2015-01-08 15:03:00','7820','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('47','2015-01-08 15:13:00','522','18','5','1','2.70','','1','0','0');
INSERT INTO `tab_print` VALUES ('48','2015-01-09 15:12:00','8350','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('49','2015-01-09 15:23:00','4946','0','0','2','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('50','2015-01-09 15:23:00','4946','2','6','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('51','2015-01-09 15:28:00','8383','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('52','2015-01-09 15:32:00','8343','14','5','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('53','2015-01-09 15:33:00','8145','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('54','2015-01-09 15:46:00','4946','3','6','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('55','2015-01-09 15:47:00','8539','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('56','2015-01-10 14:10:00','8239','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('57','2015-01-10 14:28:00','8474','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('58','2015-01-10 14:40:00','4972','33','5','1','4.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('59','2015-01-10 15:23:00','7477','15','5','1','2.25','','1','0','0');
INSERT INTO `tab_print` VALUES ('60','2015-01-10 15:25:00','92','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('61','2015-01-10 16:07:00','8075','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('62','2015-01-10 16:07:00','8075','10','6','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('65','2015-01-10 16:18:00','7346','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('64','2015-01-10 16:16:00','6979','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('66','2015-01-13 14:17:00','8509','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('67','2015-01-13 14:28:00','6115','20','5','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('68','2015-01-10 16:37:00','165','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('69','2015-01-13 14:41:00','8603','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('70','2015-01-13 15:07:00','8039','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('71','2015-01-13 15:23:00','8618','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('72','2015-01-13 15:28:00','7790','2','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('73','2015-01-13 15:29:00','8383','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('74','2015-01-13 15:53:00','405','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('75','2015-01-13 15:53:00','405','6','6','1','1.80','','1','0','0');
INSERT INTO `tab_print` VALUES ('77','2015-01-13 16:00:00','7027','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('78','2015-01-13 16:20:00','4972','13','5','1','1.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('79','2015-01-13 16:21:00','7933','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('80','2015-01-13 16:21:00','7790','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('83','2015-01-13 17:25:00','279','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('82','2015-01-13 16:43:00','8266','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('84','2015-01-13 17:25:00','279','4','6','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('85','2015-01-13 16:51:00','8266','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('86','2015-01-14 14:18:00','8559','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('87','2015-01-14 14:18:00','8559','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('88','2015-01-14 14:36:00','8546','13','5','1','1.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('89','2015-01-14 14:49:00','8187','26','5','1','3.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('90','2015-01-14 14:49:00','198','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('91','2015-01-14 14:53:00','522','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('92','2015-01-14 14:57:00','1868','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('94','2015-01-14 15:04:00','295','15','5','1','2.25','','1','0','0');
INSERT INTO `tab_print` VALUES ('95','2015-01-14 15:14:00','8539','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('96','2015-01-14 15:33:00','8334','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('97','2015-01-14 15:34:00','7716','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('98','2015-01-14 16:19:00','8466','5','6','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('99','2015-01-14 16:18:00','7986','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('100','2015-01-14 16:18:00','7986','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('101','2015-01-15 15:22:00','19','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('102','2015-01-15 15:30:00','7820','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('103','2015-01-15 15:30:00','8199','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('104','2015-01-15 15:37:00','6969','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('105','2015-01-14 16:05:00','7768','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('106','2015-01-14 16:06:00','7974','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('107','2015-01-16 15:17:00','8566','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('108','2015-01-16 15:23:00','8187','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('109','2015-01-16 15:24:00','8426','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('110','2015-01-15 15:24:00','165','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('111','2015-01-17 14:26:00','4529','3','6','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('112','2015-01-17 14:26:00','4529','1','7','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('113','2015-01-17 14:32:00','1309','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('114','2015-01-17 14:39:00','4972','50','5','1','7.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('115','2015-01-17 14:52:00','8566','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('116','2015-01-17 15:06:00','7986','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('117','2015-01-17 15:27:00','6969','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('118','2015-01-17 15:28:00','7961','35','5','1','5.25','','1','0','0');
INSERT INTO `tab_print` VALUES ('119','2015-01-17 16:38:00','165','16','6','1','4.80','','1','0','0');
INSERT INTO `tab_print` VALUES ('120','2015-01-17 17:42:00','279','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('121','2015-01-20 14:54:00','6969','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('122','2015-01-20 15:56:00','6821','15','5','1','2.25','','1','0','0');
INSERT INTO `tab_print` VALUES ('123','2015-01-20 14:56:00','8384','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('124','2015-01-20 14:57:00','3085','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('125','2015-01-20 16:58:00','8039','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('126','2015-01-21 14:44:00','8255','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('127','2015-01-21 14:51:00','8003','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('128','2015-01-21 15:01:00','279','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('129','2015-01-21 15:01:00','279','10','6','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('130','2015-01-21 15:10:00','7229','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('131','2015-01-21 16:05:00','7320','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('132','2015-01-21 16:19:00','7051','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('133','2015-01-22 15:35:00','8039','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('134','2015-01-21 15:35:00','7857','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('135','2015-01-22 15:58:00','8255','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('136','2015-01-22 15:59:00','7412','4','6','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('137','2015-01-22 15:59:00','8503','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('138','2015-01-23 14:19:00','8572','7','6','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('139','2015-01-23 15:00:00','821','20','5','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('140','2015-01-23 15:00:00','821','1','12','1','5.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('141','2015-01-23 15:03:00','7933','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('142','2015-01-23 15:03:00','7933','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('143','2015-01-23 15:14:00','8631','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('144','2015-01-21 15:15:00','7820','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('145','2015-01-24 14:34:00','6969','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('146','2015-01-24 14:38:00','8632','3','6','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('147','2015-01-24 15:08:00','4972','34','5','1','5.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('148','2015-01-24 15:15:00','7961','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('149','2015-01-24 15:31:00','7961','2','5','0','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('150','2015-01-24 16:23:00','8306','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('151','2015-01-24 16:42:00','4685','16','6','1','4.80','','1','0','0');
INSERT INTO `tab_print` VALUES ('152','2015-01-24 16:43:00','7105','10','5','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('153','2015-01-24 16:46:00','8203','1','6','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('154','2015-01-24 17:04:00','2576','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('155','2015-01-24 17:04:00','2576','5','6','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('156','2015-01-27 14:09:00','7313','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('157','2015-01-27 14:23:00','8383','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('158','2015-01-27 14:26:00','7451','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('159','2015-01-27 14:27:00','6821','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('160','2015-01-27 15:26:00','6115','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('161','2015-01-27 15:26:00','8039','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('162','2015-01-27 16:31:00','8637','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('163','2015-01-27 16:31:00','7412','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('164','2015-01-27 16:31:00','7412','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('165','2015-01-27 16:36:00','4951','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('166','2015-01-27 16:58:00','7','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('167','2015-01-27 17:02:00','2667','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('168','2015-01-27 17:09:00','7158','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('169','2015-01-28 14:17:00','3402','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('170','2015-01-28 14:19:00','4583','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('171','2015-01-28 14:21:00','7318','2','6','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('172','2015-01-28 14:21:00','404','3','12','1','15.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('173','2015-01-30 15:39:00','2667','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('174','2015-01-30 15:56:00','6993','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('247','2015-02-21 14:12:00','7107','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('176','2015-01-31 15:37:00','8641','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('177','2015-01-31 16:05:00','8642','10','5','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('178','2015-01-31 15:57:00','8400','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('179','2015-01-31 15:00:00','8559','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('180','2015-02-03 14:31:00','3085','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('182','2015-02-03 15:14:00','8452','19','5','1','2.85','','1','0','0');
INSERT INTO `tab_print` VALUES ('183','2015-02-03 15:23:00','6969','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('184','2015-02-03 15:23:00','7783','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('185','2015-02-03 15:38:00','8600','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('186','2015-02-03 15:59:00','8324','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('187','2015-02-03 16:02:00','8641','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('188','2015-02-03 16:06:00','183','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('189','2015-02-03 16:07:00','8171','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('190','2015-02-05 14:18:00','647','28','5','1','4.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('191','2015-02-05 15:40:00','6970','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('192','2015-02-06 14:06:00','647','19','5','1','2.85','','1','0','0');
INSERT INTO `tab_print` VALUES ('193','2015-02-06 14:26:00','4972','49','5','1','7.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('194','2015-02-06 15:24:00','7767','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('195','2015-02-06 15:39:00','8495','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('196','2015-02-06 15:50:00','7790','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('197','2015-02-06 16:08:00','6969','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('198','2015-02-11 14:15:00','8536','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('199','2015-02-11 14:36:00','7320','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('200','2015-02-11 15:04:00','8646','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('201','2015-02-12 14:08:00','7653','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('202','2015-02-12 14:20:00','6969','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('203','2015-02-12 14:50:00','7722','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('204','2015-02-12 15:08:00','404','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('205','2015-02-12 16:05:00','616','14','5','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('206','2015-02-13 14:59:00','8495','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('207','2015-02-13 15:20:00','8290','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('208','2015-02-17 14:54:00','371','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('209','2015-02-17 14:55:00','6969','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('210','2015-02-17 14:56:00','7768','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('211','2015-02-17 14:56:00','647','11','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('212','2015-02-17 14:56:00','647','0','0','2','1.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('213','2015-02-17 14:58:00','427','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('214','2015-02-14 14:58:00','7318','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('215','2015-02-17 15:00:00','8324','2','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('216','2015-02-17 15:00:00','8324','0','0','2','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('217','2015-02-17 15:14:00','5','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('218','2015-02-17 15:59:00','7466','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('219','2015-02-17 16:55:00','271','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('220','2015-02-17 16:55:00','8651','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('221','2015-02-17 16:56:00','616','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('222','2015-02-17 16:56:00','7883','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('223','2015-02-17 16:57:00','661','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('224','2015-02-17 16:58:00','7981','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('225','2015-02-18 14:46:00','7882','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('226','2015-02-18 16:47:00','7426','12','5','1','1.80','','1','0','0');
INSERT INTO `tab_print` VALUES ('227','2015-02-18 16:57:00','2992','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('228','2015-02-18 15:52:00','8419','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('229','2015-02-18 15:52:00','522','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('230','2015-02-18 15:53:00','8384','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('231','2015-02-18 14:54:00','6807','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('232','2015-02-19 14:50:00','7489','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('233','2015-02-19 14:55:00','8566','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('234','2015-02-19 15:05:00','616','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('235','2015-02-19 15:19:00','8089','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('236','2015-02-19 15:53:00','589','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('237','2015-02-19 15:53:00','8104','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('238','2015-02-19 15:54:00','8610','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('240','2015-02-19 16:04:00','1309','2','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('241','2015-02-19 16:04:00','1309','0','0','2','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('242','2015-02-20 14:17:00','7256','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('243','2015-02-20 14:17:00','371','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('245','2015-02-20 15:09:00','8624','0','0','2','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('246','2015-02-20 15:12:00','1309','0','0','2','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('248','2015-02-21 15:22:00','7768','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('249','2015-02-24 14:23:00','4275','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('250','2015-02-24 14:24:00','6969','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('251','2015-02-21 14:25:00','8624','1','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('252','2015-02-19 14:26:00','8239','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('253','2015-02-14 14:27:00','8405','22','5','1','3.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('254','2015-02-14 14:27:00','8405','1','12','1','5.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('255','2015-02-17 14:29:00','8405','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('256','2015-02-17 14:32:00','8187','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('257','2015-02-14 14:33:00','8419','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('258','2015-02-17 14:34:00','3085','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('259','2015-02-24 14:57:00','8509','33','5','1','4.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('260','2015-02-24 15:22:00','8372','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('261','2015-02-24 16:07:00','7857','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('262','2015-02-25 14:23:00','8571','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('263','2015-02-25 14:25:00','7853','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('264','2015-02-25 15:04:00','7312','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('265','2015-02-25 15:06:00','677','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('266','2015-02-25 15:12:00','522','27','5','1','4.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('267','2015-02-25 16:00:00','8039','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('268','2015-02-26 15:36:00','8350','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('269','2015-02-26 15:54:00','8663','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('270','2015-03-06 14:47:00','8251','14','5','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('271','2015-03-06 15:59:00','8618','2','5','1','0.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('272','2015-03-06 15:59:00','8618','0','0','2','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('273','2015-03-10 15:19:00','11','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('274','2015-03-10 15:20:00','8665','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('275','2015-03-10 16:02:00','6969','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('276','2015-03-10 16:03:00','8603','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('277','2015-03-07 16:03:00','7768','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('278','2015-03-07 16:04:00','7722','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('279','2015-03-06 16:05:00','7402','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('280','2015-03-06 16:06:00','198','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('281','2015-03-06 16:07:00','8603','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('282','2015-03-06 16:09:00','7229','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('283','2015-03-10 16:10:00','8293','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('284','2015-03-11 14:02:00','8089','14','5','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('285','2015-03-11 15:08:00','677','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('286','2015-03-11 17:51:00','624','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('287','2015-03-11 16:32:00','4583','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('288','2015-03-10 16:33:00','165','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('289','2015-03-10 16:34:00','8527','10','5','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('290','2015-03-11 17:04:00','8527','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('291','2015-03-11 15:35:00','522','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('292','2015-03-13 15:10:00','8665','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('293','2015-03-13 15:35:00','8650','10','5','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('294','2015-03-13 15:36:00','8293','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('295','2015-03-13 15:37:00','7027','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('296','2015-03-11 14:38:00','8543','20','5','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('297','2015-03-14 14:45:00','8585','13','5','1','1.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('298','2015-03-14 15:11:00','283','10','5','1','1.50','','1','0','0');
INSERT INTO `tab_print` VALUES ('299','2015-03-14 15:11:00','8251','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('300','2015-03-14 15:12:00','7429','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('301','2015-03-14 16:10:00','6969','14','5','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('302','2015-03-14 16:12:00','8673','14','5','1','2.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('303','2015-03-17 14:26:00','4178','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('304','2015-03-17 14:26:00','8509','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('305','2015-03-17 14:27:00','8089','18','5','1','2.70','','1','0','0');
INSERT INTO `tab_print` VALUES ('306','2015-03-17 14:57:00','8426','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('307','2015-03-17 15:10:00','404','19','5','1','2.85','','1','0','0');
INSERT INTO `tab_print` VALUES ('311','2015-03-17 15:38:00','8665','18','5','1','2.70','','1','0','0');
INSERT INTO `tab_print` VALUES ('310','2015-03-17 15:21:00','8618','8','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('312','2015-03-17 17:19:00','7412','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('313','2015-03-17 17:19:00','8324','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('314','2015-03-17 17:22:00','8676','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('318','2015-03-18 17:01:00','7820','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('316','2015-03-18 14:15:00','8089','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('317','2015-03-18 14:39:00','677','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('319','2015-03-24 14:19:00','647','8','5','1','1.10','','1','0','0');
INSERT INTO `tab_print` VALUES ('320','2015-03-24 14:19:00','647','2','12','1','10.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('321','2015-03-24 14:38:00','8650','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('322','2015-03-24 15:23:00','7850','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('323','2015-03-24 15:23:00','7180','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('324','2015-03-24 15:44:00','183','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('326','2015-03-24 17:22:00','624','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('327','2015-03-24 17:22:00','165','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('328','2015-03-24 17:23:00','7105','5','5','1','0.75','','1','0','0');
INSERT INTO `tab_print` VALUES ('329','2015-03-24 17:33:00','7105','7','5','1','1.05','','1','0','0');
INSERT INTO `tab_print` VALUES ('330','2015-03-25 17:04:00','7820','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('331','2015-03-25 17:33:00','8040','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('332','2015-03-25 17:35:00','522','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('333','2015-03-25 17:36:00','8422','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('334','2015-03-25 17:36:00','7790','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('335','2015-03-25 17:36:00','8465','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('336','2015-03-21 17:37:00','4583','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('337','2015-03-24 17:41:00','8465','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('338','2015-03-20 17:42:00','7692','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('339','2015-03-18 16:47:00','8672','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('340','2015-03-24 17:47:00','8656','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('341','2015-03-21 16:48:00','8251','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('342','2015-03-21 16:50:00','8694','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('343','2015-03-21 16:50:00','4582','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('344','2015-02-20 15:53:00','7412','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('345','2015-03-20 16:53:00','8681','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('346','2015-03-24 14:55:00','8695','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('347','2015-03-20 14:57:00','8696','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('348','2015-03-26 14:06:00','8089','9','5','1','1.35','','1','0','0');
INSERT INTO `tab_print` VALUES ('357','2015-03-31 15:51:00','8603','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('350','2015-03-27 14:36:00','8610','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('351','2015-03-27 14:55:00','8631','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('352','2015-03-31 14:53:00','8400','18','5','1','2.70','','1','0','0');
INSERT INTO `tab_print` VALUES ('353','2015-03-31 15:03:00','8603','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('354','2015-03-31 15:49:00','8683','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('355','2015-03-31 15:49:00','7820','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('356','2015-03-27 15:50:00','8665','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('358','2015-03-31 15:51:00','427','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('359','2015-03-31 15:51:00','7850','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('360','2015-03-27 15:52:00','7256','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('361','2015-03-28 15:53:00','6059','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('362','2015-03-27 16:00:00','7313','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('363','2015-03-31 16:00:00','8665','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('364','2015-03-28 16:01:00','7722','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('365','2015-04-01 14:28:00','4911','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('366','2015-04-01 16:20:00','5865','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('367','2015-04-01 16:21:00','8400','12','5','1','1.80','','1','0','0');
INSERT INTO `tab_print` VALUES ('368','2015-04-01 16:34:00','8702','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('369','2015-04-02 14:20:00','183','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('370','2015-04-02 14:56:00','19','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('371','2015-04-01 15:00:00','8104','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('372','2015-03-31 15:00:00','8687','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('373','2015-04-01 15:10:00','236','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('374','2015-04-01 15:12:00','8485','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('375','2015-04-02 16:02:00','159','23','5','1','3.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('376','2015-04-02 16:03:00','677','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('377','2015-04-02 14:59:00','8618','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('378','2015-03-27 14:01:00','6969','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('379','2015-04-04 14:28:00','677','8','5','1','1.20','','1','0','0');
INSERT INTO `tab_print` VALUES ('380','2015-04-04 14:38:00','6807','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('381','2015-04-04 15:29:00','677','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('382','2015-04-04 15:30:00','165','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('383','2015-04-04 16:10:00','6969','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('384','2015-04-04 16:13:00','1554','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('385','2015-04-04 16:35:00','8709','13','5','1','1.95','','1','0','0');
INSERT INTO `tab_print` VALUES ('386','2015-04-11 15:25:00','7412','6','5','1','0.90','','1','0','0');
INSERT INTO `tab_print` VALUES ('387','2015-04-11 17:26:00','4695','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('388','2015-04-11 17:26:00','5271','20','5','1','3.00','','1','0','0');
INSERT INTO `tab_print` VALUES ('389','2015-04-11 16:27:00','5097','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('390','2015-04-11 15:27:00','165','3','5','1','0.45','','1','0','0');
INSERT INTO `tab_print` VALUES ('391','2015-04-11 17:27:00','7882','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('392','2015-04-11 17:00:00','8330','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('393','2015-04-11 17:10:00','8712','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('394','2015-04-14 14:42:00','8089','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('395','2015-04-14 14:43:00','6506','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('396','2015-04-14 14:45:00','8715','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('397','2015-04-14 15:06:00','7820','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('398','2015-04-14 15:08:00','8713','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('399','2015-04-14 15:46:00','8316','4','5','1','0.60','','1','0','0');
INSERT INTO `tab_print` VALUES ('400','2015-04-14 15:49:00','8007','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('401','2015-04-14 15:57:00','8530','1','5','1','0.15','','1','0','0');
INSERT INTO `tab_print` VALUES ('402','2015-04-14 16:35:00','8656','2','5','1','0.30','','1','0','0');
INSERT INTO `tab_print` VALUES ('403','2015-04-15 14:32:00','6969','10','5','1','1.50','0','1','1','0');
INSERT INTO `tab_print` VALUES ('404','2015-04-17 14:57:00','5097','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('405','2015-04-17 16:00:00','8665','2','5','1','0.30','0','1','1','0');
INSERT INTO `tab_print` VALUES ('406','2015-04-17 16:00:00','8718','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('407','2015-04-17 16:00:00','8719','3','5','1','0.45','0','1','1','0');
INSERT INTO `tab_print` VALUES ('408','2015-04-17 16:01:00','198','3','5','1','0.45','0','1','1','0');
INSERT INTO `tab_print` VALUES ('409','2015-04-17 16:01:00','4222','14','5','1','2.10','0','1','1','0');
INSERT INTO `tab_print` VALUES ('410','2015-04-18 14:03:00','8343','15','5','1','2.25','0','1','1','0');
INSERT INTO `tab_print` VALUES ('411','2015-04-18 14:18:00','8362','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('412','2015-04-18 15:48:00','8511','6','5','1','0.90','0','1','1','0');
INSERT INTO `tab_print` VALUES ('413','2015-04-18 16:08:00','8665','8','5','1','1.20','0','1','1','0');
INSERT INTO `tab_print` VALUES ('414','2015-04-18 16:47:00','7045','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('415','2015-04-21 14:18:00','198','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('416','2015-04-21 14:27:00','7966','3','5','1','0.45','0','1','1','0');
INSERT INTO `tab_print` VALUES ('417','2015-04-21 14:32:00','8089','2','5','1','0.30','0','1','1','0');
INSERT INTO `tab_print` VALUES ('418','2015-04-21 14:42:00','7555','6','5','1','0.90','0','1','1','0');
INSERT INTO `tab_print` VALUES ('419','2015-04-21 15:33:00','653','5','5','1','0.75','0','1','1','0');
INSERT INTO `tab_print` VALUES ('420','2015-04-21 15:47:00','7790','2','5','1','0.30','0','1','1','0');
INSERT INTO `tab_print` VALUES ('421','2015-04-21 16:43:00','7412','6','5','1','0.90','0','1','1','0');
INSERT INTO `tab_print` VALUES ('422','2015-04-21 16:56:00','8624','5','5','1','0.75','0','1','1','0');
INSERT INTO `tab_print` VALUES ('423','2015-04-22 15:39:00','8683','2','5','1','0.30','0','1','1','0');
INSERT INTO `tab_print` VALUES ('424','2015-04-22 15:42:00','8638','10','5','1','1.50','0','1','1','0');
INSERT INTO `tab_print` VALUES ('425','2015-04-22 16:21:00','7768','3','5','1','0.45','0','1','1','0');
INSERT INTO `tab_print` VALUES ('426','2015-04-22 16:37:00','8722','4','5','1','0.60','0','1','1','0');
INSERT INTO `tab_print` VALUES ('427','2015-04-22 16:53:00','8724','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('428','2015-04-22 17:07:00','6993','4','5','1','0.60','0','1','1','0');
INSERT INTO `tab_print` VALUES ('429','2015-04-22 17:36:00','1650','3','5','1','0.45','0','1','1','0');
INSERT INTO `tab_print` VALUES ('430','2015-04-22 17:39:00','5271','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('431','2015-04-22 17:40:00','8450','2','5','1','0.30','0','1','1','0');
INSERT INTO `tab_print` VALUES ('432','2015-04-23 15:43:00','7722','11','5','1','1.65','0','1','1','0');
INSERT INTO `tab_print` VALUES ('433','2015-04-22 17:06:00','8428','10','5','1','1.50','0','1','1','0');
INSERT INTO `tab_print` VALUES ('434','2015-04-23 15:06:00','8727','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('435','2015-04-24 14:47:00','8489','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('436','2015-04-24 15:02:00','7346','8','5','1','1.20','0','1','1','0');
INSERT INTO `tab_print` VALUES ('437','2015-04-25 14:04:00','8007','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('438','2015-04-25 15:48:00','8601','25','5','0','3.75','0','1','1','0');
INSERT INTO `tab_print` VALUES ('439','2015-04-25 15:48:00','8601','1','12','0','5.00','0','1','1','0');
INSERT INTO `tab_print` VALUES ('440','2015-04-28 14:07:00','8618','26','5','1','3.90','0','1','1','0');
INSERT INTO `tab_print` VALUES ('441','2015-04-28 15:24:00','8089','5','5','1','0.75','0','1','1','0');
INSERT INTO `tab_print` VALUES ('442','2015-04-28 15:24:00','8089','1','12','1','5.00','0','1','1','0');
INSERT INTO `tab_print` VALUES ('443','2015-04-25 14:05:00','7783','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('444','2015-04-28 16:05:00','3968','5','5','1','0.75','0','1','1','0');
INSERT INTO `tab_print` VALUES ('445','2015-04-29 14:11:00','8418','1','5','1','0.15','0','1','1','0');
INSERT INTO `tab_print` VALUES ('446','2015-04-29 15:35:00','7853','3','5','1','0.45','0','1','1','0');
INSERT INTO `tab_print` VALUES ('447','2015-04-29 15:27:00','4594','4','5','1','0.60','','1','0','0');


DROP TABLE IF EXISTS `tab_resa`;
CREATE TABLE `tab_resa` (
  `id_resa` int(11) NOT NULL AUTO_INCREMENT,
  `id_computer_resa` int(11) NOT NULL,
  `id_user_resa` int(11) NOT NULL,
  `dateresa_resa` date NOT NULL,
  `debut_resa` int(11) NOT NULL,
  `duree_resa` int(11) NOT NULL,
  `date_resa` date NOT NULL,
  `status_resa` enum('0','1','2') COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_resa`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_resa` VALUES ('1','8','7','2015-09-02','840','10','2015-09-02','1');
INSERT INTO `tab_resa` VALUES ('2','8','19','2015-09-02','860','90','2015-09-02','1');
INSERT INTO `tab_resa` VALUES ('3','9','6','2015-09-02','600','60','2015-09-02','1');
INSERT INTO `tab_resa` VALUES ('4','7','19','2015-09-02','660','30','2015-09-02','1');
INSERT INTO `tab_resa` VALUES ('5','17','18','2015-10-06','660','60','2015-10-08','1');
INSERT INTO `tab_resa` VALUES ('6','7','7','2015-10-06','870','32','2015-10-08','1');
INSERT INTO `tab_resa` VALUES ('7','7','8','2015-10-06','930','40','2015-10-08','1');


DROP TABLE IF EXISTS `tab_salle`;
CREATE TABLE `tab_salle` (
  `id_salle` int(11) NOT NULL AUTO_INCREMENT,
  `nom_salle` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_espace` int(11) NOT NULL,
  `comment_salle` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_salle`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_salle` VALUES ('1','Espace Consultation','1','');
INSERT INTO `tab_salle` VALUES ('2','Espace Ateliers','1','');
INSERT INTO `tab_salle` VALUES ('3','Ateliers du Test','2','');


DROP TABLE IF EXISTS `tab_session`;
CREATE TABLE `tab_session` (
  `id_session` int(11) NOT NULL AUTO_INCREMENT,
  `date_session` date NOT NULL,
  `nom_session` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nbplace_session` int(11) NOT NULL,
  `nbre_dates_sessions` int(11) NOT NULL,
  `status_session` int(11) NOT NULL,
  `id_anim` int(11) NOT NULL,
  `id_salle` int(11) NOT NULL,
  `id_tarif` int(11) NOT NULL,
  PRIMARY KEY (`id_session`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_session` VALUES ('2','2015-08-28','1','4','2','0','22','2','1');


DROP TABLE IF EXISTS `tab_session_dates`;
CREATE TABLE `tab_session_dates` (
  `id_datesession` int(11) NOT NULL AUTO_INCREMENT,
  `id_session` int(11) NOT NULL,
  `date_session` datetime NOT NULL,
  `statut_datesession` int(11) NOT NULL,
  PRIMARY KEY (`id_datesession`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_session_dates` VALUES ('1','2','2015-08-20 22:26:00','0');
INSERT INTO `tab_session_dates` VALUES ('2','2','2015-08-28 22:26:00','0');


DROP TABLE IF EXISTS `tab_session_sujet`;
CREATE TABLE `tab_session_sujet` (
  `id_session_sujet` int(11) NOT NULL AUTO_INCREMENT,
  `session_titre` varchar(300) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `session_detail` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `session_niveau` int(11) NOT NULL,
  `session_categorie` int(11) NOT NULL,
  PRIMARY KEY (`id_session_sujet`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_session_sujet` VALUES ('1','Cr�ation de site internet','tout sur le blog','3','5');
INSERT INTO `tab_session_sujet` VALUES ('2','grands d�butants Internet','Pour d�buter sur Internet, les bases de la navigation et de la messagerie sur 4 ateliers','1','5');
INSERT INTO `tab_session_sujet` VALUES ('3','Grand d�butant en Ordinateur','Sp�cial Windows 8. Bien d�marrer et comprendre sur son nouvel ordinateur. Manipuler le clavier, la souris, cr�er des dossiers et ranger, les bases pour tout faire !','1','3');
INSERT INTO `tab_session_sujet` VALUES ('4','Grand d�butant en Messagerie','Envoyer/recevoir ses messages, les contacts, les pi�ces jointes, tout savoir sur la messagerie facile.','1','6');


DROP TABLE IF EXISTS `tab_tarifs`;
CREATE TABLE `tab_tarifs` (
  `id_tarif` int(11) NOT NULL AUTO_INCREMENT,
  `nom_tarif` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `donnee_tarif` decimal(10,2) NOT NULL,
  `comment_tarif` varchar(300) COLLATE latin1_general_ci NOT NULL,
  `nb_atelier_forfait` int(11) NOT NULL,
  `categorie_tarif` int(11) NOT NULL,
  `duree_tarif` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `epn_tarif` varchar(200) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tarif`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_tarifs` VALUES ('1','sans tarif','0.00','ateliers illimit�s','0','5','0','');
INSERT INTO `tab_tarifs` VALUES ('2','Adh�sion adulte normal','12.00','tarif payant adulte Agglom�ration','0','2','','1-2');
INSERT INTO `tab_tarifs` VALUES ('3','Adh�sion adulte exterieur ','30.00','tarif payant adulte hors agglom�ration','0','2','','1');
INSERT INTO `tab_tarifs` VALUES ('4','Adhesion gratuite ','0.00','tarif gratuit','0','2','','1-2');
INSERT INTO `tab_tarifs` VALUES ('5','A4 Noir et Blanc   ','0.15','1 page NB','0','1','','1-2');
INSERT INTO `tab_tarifs` VALUES ('6','A4 Couleur ','0.30','1 page couleur','0','1','','1');
INSERT INTO `tab_tarifs` VALUES ('7','A3 Noir et Blanc ','0.30','1 page A3 nb','0','1','','2');
INSERT INTO `tab_tarifs` VALUES ('13','Atelier unique ','1.00','1 atelier pour tester','1','5','','1');
INSERT INTO `tab_tarifs` VALUES ('10','Adh�sion Jeune  ','2.00','tarif jeune gratuit','0','2','','1');
INSERT INTO `tab_tarifs` VALUES ('11','A3 Couleur ','0.60','1 page A3 couleur','0','1','','2');
INSERT INTO `tab_tarifs` VALUES ('14','session','10.00','10 ateliers','10','5','1-1','1');


DROP TABLE IF EXISTS `tab_transactions`;
CREATE TABLE `tab_transactions` (
  `id_transac` int(11) NOT NULL AUTO_INCREMENT,
  `type_transac` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_tarif` int(11) NOT NULL,
  `nbr_forfait` int(11) NOT NULL,
  `date_transac` date NOT NULL,
  `status_transac` int(11) NOT NULL,
  PRIMARY KEY (`id_transac`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_transactions` VALUES ('1','adh','13','2','1','2015-07-27','1');
INSERT INTO `tab_transactions` VALUES ('2','for','13','13','5','2015-07-27','1');
INSERT INTO `tab_transactions` VALUES ('3','for','19','14','1','2015-07-27','1');
INSERT INTO `tab_transactions` VALUES ('5','temps','7','2','1','2015-08-07','1');
INSERT INTO `tab_transactions` VALUES ('6','adh','7','2','1','2015-08-07','1');
INSERT INTO `tab_transactions` VALUES ('7','adh','7','4','1','2015-08-07','1');
INSERT INTO `tab_transactions` VALUES ('8','temps','19','1','1','2015-08-07','1');
INSERT INTO `tab_transactions` VALUES ('9','temps','6','1','1','2015-08-07','1');
INSERT INTO `tab_transactions` VALUES ('11','for','6','13','0','2015-08-07','1');
INSERT INTO `tab_transactions` VALUES ('12','adh','15','10','1','2014-08-19','1');
INSERT INTO `tab_transactions` VALUES ('13','adh','16','4','1','2015-08-21','1');
INSERT INTO `tab_transactions` VALUES ('14','adh','7','4','1','2015-08-21','1');
INSERT INTO `tab_transactions` VALUES ('15','adh','7','4','1','2015-08-21','1');
INSERT INTO `tab_transactions` VALUES ('16','temps','11','3','1','2015-09-02','1');
INSERT INTO `tab_transactions` VALUES ('17','temps','18','2','1','2015-09-02','1');


DROP TABLE IF EXISTS `tab_url`;
CREATE TABLE `tab_url` (
  `id_url` int(11) NOT NULL AUTO_INCREMENT,
  `iduser_url` int(11) NOT NULL DEFAULT '0',
  `titre_url` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `url_url` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_url`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_url_rub`;
CREATE TABLE `tab_url_rub` (
  `id_url_rub` int(11) NOT NULL AUTO_INCREMENT,
  `iduser_url_rub` int(11) NOT NULL,
  `label_url_rub` varchar(250) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_url_rub`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


DROP TABLE IF EXISTS `tab_usage`;
CREATE TABLE `tab_usage` (
  `id_usage` int(11) NOT NULL AUTO_INCREMENT,
  `nom_usage` varchar(80) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type_usage` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id_usage`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_usage` VALUES ('1','Capture/Montage video','public');
INSERT INTO `tab_usage` VALUES ('2','Scanner','public');
INSERT INTO `tab_usage` VALUES ('3','Gravure CD/DVD','public');
INSERT INTO `tab_usage` VALUES ('4','Capture/Montage audio','public');
INSERT INTO `tab_usage` VALUES ('5','jeux vid&eacute;o','public');
INSERT INTO `tab_usage` VALUES ('6','Lecture cartes','public');
INSERT INTO `tab_usage` VALUES ('7','impression','public');
INSERT INTO `tab_usage` VALUES ('8','Navigation Internet','public');
INSERT INTO `tab_usage` VALUES ('9','Messagerie Instantan&eacute;e ','public');


DROP TABLE IF EXISTS `tab_user`;
CREATE TABLE `tab_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `date_insc_user` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nom_user` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `prenom_user` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sexe_user` char(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `jour_naissance_user` int(2) NOT NULL DEFAULT '0',
  `mois_naissance_user` int(2) NOT NULL DEFAULT '0',
  `annee_naissance_user` int(4) NOT NULL DEFAULT '0',
  `adresse_user` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ville_user` int(11) NOT NULL DEFAULT '0',
  `tel_user` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `mail_user` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `temps_user` int(11) NOT NULL DEFAULT '0',
  `login_user` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pass_user` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `status_user` int(2) NOT NULL DEFAULT '0',
  `lastvisit_user` date NOT NULL,
  `csp_user` int(11) NOT NULL DEFAULT '0',
  `equipement_user` varchar(60) COLLATE latin1_general_ci DEFAULT NULL,
  `utilisation_user` int(11) NOT NULL,
  `connaissance_user` int(11) NOT NULL,
  `info_user` text COLLATE latin1_general_ci NOT NULL,
  `tarif_user` int(11) NOT NULL,
  `dateRen_user` date NOT NULL,
  `epn_user` int(11) NOT NULL,
  `newsletter_user` int(11) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `date_user` (`date_insc_user`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_user` VALUES ('1','2014-01-01','admin','administrateur','H','1','1','1977','rue du libre','1','00-00-00-00-00','','999','admin','21232f297a57a5a743894a0e4a801fc3','4','2015-10-11','2','','0','0','0','0','2015-01-01','1','1');
INSERT INTO `tab_user` VALUES ('4','2012-05-22','PAYEN','Kevin','H','5','4','1989','rue de la cour tournante','1','00-00-00-00-00','','1','PAYEN','31c9f1a6b53d59fa813510e5bf3a3caf','1','0000-00-00','4','0','0','0','0','2','2015-05-22','1','0');
INSERT INTO `tab_user` VALUES ('5','2012-05-19','OUCHRI','Ines','F','2','7','2002','rue de la cour tournante','1','00-00-00-00-00','','1','OUCHRI','922f8a763d1aabcfb72a36e5fb41fde8','1','0000-00-00','3','0','0','0','','10','2015-05-19','1','0');
INSERT INTO `tab_user` VALUES ('6','2012-05-19','JULIEN','Jessica','F','12','1','1993','rue de la cour tournante','2','00-00-00-00-00','','1','JULIEN','3d15d5eefedc9c00cb5783e2ae72b8d2','1','0000-00-00','2','0','0','0','','2','2015-05-19','1','0');
INSERT INTO `tab_user` VALUES ('7','2009-09-22','BENMAMI','Chabbi','F','24','12','1972','rue de la cour tournante','1','00-00-00-00-00','','0','BENMAMI','3d19e6af7ec892eda95f1902899da34b','1','2015-07-31','8','1','0','0','','4','2011-09-22','1','0');
INSERT INTO `tab_user` VALUES ('8','2012-05-19','MUKUMBI','Merveille','F','12','6','2000','rue de la cour tournante','1','00-00-00-00-00','','1','MUKUMBI','cbf65aa9ab668f9c7adef0eb5e240a56','1','0000-00-00','3','0','0','0','','10','2015-05-19','1','0');
INSERT INTO `tab_user` VALUES ('9','2012-05-19','KEPINSKI','Brigitte','F','22','10','1971','rue de la cour tournante','1','00-00-00-00-00','','1','KEPINSKI','3e060125fd005c63358289a2ac7bb4de','1','2015-08-06','2','0','0','0','','2','2015-05-19','1','0');
INSERT INTO `tab_user` VALUES ('10','2012-05-18','TOURE','Salimou','H','1','9','1987','rue de la cour tournante','2','00-00-00-00-00','','1','TOURE','69a2cf2b5a72384c966a7b9049088756','1','0000-00-00','13','0','0','0','','2','2015-05-18','1','0');
INSERT INTO `tab_user` VALUES ('11','2012-05-18','CARMIGNAC','H�l�ne','F','22','2','1963','rue de la cour tournante','3','00-00-00-00-00','','1','CARMIGNAC','bb7ed47c8c2b51218ed8a91380867b26','1','0000-00-00','2','0','0','0','','2','2015-05-18','1','0');
INSERT INTO `tab_user` VALUES ('12','2012-05-22','KIMBUMA','Papy Charly','H','5','9','1979','rue de la cour tournante','2','00-00-00-00-00','','1','KIMBUMA','eebe5c68b73a1e5dd96fd9b7a42082f7','1','0000-00-00','13','0','0','0','','2','2015-05-22','1','0');
INSERT INTO `tab_user` VALUES ('13','2009-09-22','GRANDJEAN','Monique','F','22','7','1947','rue de la cour tournante','3','00-00-00-00-00','','1','GRANDJEAN','48517a35db7807f4d86aeaa4903871bb','1','2009-07-25','1','0','0','0','','2','2016-07-26','1','0');
INSERT INTO `tab_user` VALUES ('14','2012-05-16','GOIS','Benjamin','H','2','2','1983','rue de la cour tournante','1','00-00-00-00-00','','0','GOIS','7c9397a1c93177065709e24a594e1097','6','2015-10-08','2','0','0','0','','0','2013-05-16','1','0');
INSERT INTO `tab_user` VALUES ('15','2014-08-19','LE GAL','M�lina','F','17','9','1996','rue de la cour tournante','3','00-00-00-00-00','','0','LE GAL','b6a3a143d9e20d482949aa6a7ff65729','1','0000-00-00','6','0','0','0','','10','2015-08-20','1','0');
INSERT INTO `tab_user` VALUES ('16','2012-05-15','BEBO-ALVES','Lilyah','F','16','4','1996','rue de la cour tournante','1','00-00-00-00-00','','0','BEBO-ALVES','f73ec6bf0fc974f24481e0ffe7343f85','2','0000-00-00','3','0','0','0','','10','2013-05-15','1','0');
INSERT INTO `tab_user` VALUES ('17','2012-05-12','GUEYE','Aminata','F','27','6','2000','rue de la cour tournante','2','00-00-00-00-00','','1','GUEYE','2e8b20da008845304f6e09bb330ddaab','1','0000-00-00','3','0','0','0','','10','2015-05-12','1','0');
INSERT INTO `tab_user` VALUES ('18','2009-09-22','CHABOTY','Laura','F','8','3','1989','rue de la cour tournante','2','00-00-00-00-00','','1','CHABOTY','f045bfbfd68f02b70d0f4030ee4dc557','1','2015-07-16','7','0','0','0','','2','2015-09-21','1','0');
INSERT INTO `tab_user` VALUES ('19','2009-09-22','GROB','Michel','H','7','3','1952','rue de la cour tournante','2','00-00-00-00-00','','1','GROB','09fa67f0ab5574094ea44e10a145c47f','1','0000-00-00','4','0','0','0','','2','2015-09-21','1','0');
INSERT INTO `tab_user` VALUES ('20','2009-09-22','MEHEUST','G�rard','H','16','8','1947','rue de la cour tournante','3','00-00-00-00-00','','1','MEHEUST','2c817bec6550b9498fc338451eb77339','1','0000-00-00','1','0','0','0','','2','2015-09-21','1','0');
INSERT INTO `tab_user` VALUES ('21','2015-07-16','Animateur','Georges','F','1','1','1987','rue de la cour tournante','2','00-00-00-00-00','','999','animateur','8e3677d7ba286f0d62b70a1742ee22e9','3','2015-08-18','2','','0','0','','2','2016-07-15','1','1');
INSERT INTO `tab_user` VALUES ('22','2015-08-18','Test','Sylvain','H','1','1','1978','rue du libre','3','','','999','Testanim','6cb1bdea77308b25dd6137ad4843c97d','3','2015-08-18','2','','0','0','','0','2016-08-17','1','1');


DROP TABLE IF EXISTS `tab_utilisation`;
CREATE TABLE `tab_utilisation` (
  `id_utilisation` int(11) NOT NULL AUTO_INCREMENT,
  `nom_utilisation` varchar(75) COLLATE latin1_general_ci NOT NULL,
  `type_menu` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `visible` varchar(3) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_utilisation`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tab_utilisation` VALUES ('1','Bureautique','Menu Principal','oui');
INSERT INTO `tab_utilisation` VALUES ('2','Consultation/actualisation du dossier de demandeur d''emploi','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('3','Gravure CD/DVD','Menu Principal','oui');
INSERT INTO `tab_utilisation` VALUES ('4','Recherche d''information','Menu Principal','oui');
INSERT INTO `tab_utilisation` VALUES ('5','CV, Lettre de motivation','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('6','D&eacute;marches de creation ou reprise d''entreprise','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('7','Suivi de candidatures','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('8','Internet','Menu Principal','oui');
INSERT INTO `tab_utilisation` VALUES ('9','Vie quotidienne, loisirs, sport, vacances','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('10','Enseignement, formation','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('11','Recherches et consultations d''offres, candidature','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('12','E-administration','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('13','E-commerce','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('14','Services numeriques scolaires','Sous Menu','oui');
INSERT INTO `tab_utilisation` VALUES ('15','Autres','Menu Principal','oui');
